# Django
DJANGO_SECRET_KEY = '62c842ff3688e64045a7a90f45d10985'
HTTP_API_SECRET = 'ce682dfe15a227eec1101359929c54a2'
DEFAULT_DB_CONFIG = {
    'ENGINE': 'django.db.backends.postgresql_psycopg2',
    'NAME': 'pda_cms',
    'USER': 'pda_cms_user',
    'PASSWORD': 'Logitech@1108',
    'HOST': 'localhost',
    'PORT': '5432',
}

# Postgres
PSQL_HOST = '43.251.253.240'
PSQL_PORT = '5430'
PSQL_USER = 'airflow_usr'
PSQL_PSWD = 'zxcvzxcv'
PSQL_SCH_01_A = 'public'
PSQL_DB_01 = 'pd_api_backend'
PSQL_DB_03 = 'pda_stats'
PSQL_TAB_01_A = 'user'


PSQL_HOST_02 = 'localhost'
PSQL_PORT_02 = '5432'
PSQL_USER_02 = 'check_service_status_user'
PSQL_PSWD_02 = 'asdf.123'
PSQL_DB_02 = 'check_service_status'

# Mongo
MONGO_URI = 'mongodb://pligencebackendcode_user_1_247:VdKJhPgnqrzxcvMPzyk3k5nqaF247kRkCEQV6SZuPHvqDkPSehYnYas3nnLw5ttMTKCTAJEA7pliGL5ZjcQtmkf7SXZ6aBzDnasaQ3eMYkAAcKdSbP@43.251.253.240:27010/?authSource=admin&readPreference=primary&appname=pda-cms-backend-django&ssl=false'

MONGO_URI2 = "mongodb://localhost:27017/?readPreference=primary&appname=MongoDB%20Compass&directConnection=true&ssl=false"

MONGO_DB_01 = 'pdps_stage_db'
MONGO_DB_02 = 'use_case_db'
MONGO_DB_03 = 'notifications_db'
MONGO_DB_04 = 'app_suspicious_db'
MONGO_DB_05 = 'app_whitelist_db'
MONGO_DB_06 = 'suspicious_use_case_config_db'
MONGO_DB_07 = 'user_feedback'
MONGO_DB_08 = 'system_usage_db'

MONGO_COL_01_A = 'users'
MONGO_COL_01_B = 'host_response'
MONGO_COL_01_C = 'app_installed_response'
MONGO_COL_01_D = 'app_sensor_response'
MONGO_COL_01_E = 'app_permission_response'
MONGO_COL_02_A = 'notifications'
MONGO_COL_02_B = 'suspicious_app_notifications'
MONGO_COL_02_C = 'bulk_process_malicious_notification'
MONGO_COL_02_D = 'calender_and_reboot_use_case'
MONGO_COL_02_E = 'malicious_app_use_cases'
MONGO_COL_02_F = 'possible_data_ex_filtration_use_case'
MONGO_COL_02_G = 'sensor_duration_use_case'
MONGO_COL_02_H = 'suspicious_completed_notifications'
MONGO_COL_02_I = 'unverified_app_notifications'
MONGO_COL_02_J = 'unverified_completed_notifications'
MONGO_COL_02_K = 'malicious_app_via_other_means_use_case'
MONGO_COL_02_L = 'valid_bulk_app_notifications'
MONGO_COL_02_M = 'firewall_use_cases'
MONGO_COL_03_A = 'news'
MONGO_COL_03_B = 'announcement'
MONGO_COL_03_C = 'false_positive'
MONGO_COL_03_D = 'announcement_external_link'
MONGO_COL_03_E = 'security_scan'
MONGO_COL_04_A = '_primary'
MONGO_COL_05_A = 'whitelist_apps'
MONGO_COL_06_A = 'suspicious_whitelist'
MONGO_COL_06_B = 'verified_app_source'
MONGO_COL_06_C = 'dangerous_permission'
MONGO_COL_07_A = 'firewall_rules'
MONGO_COL_08_A = 'cpu_usage'
MONGO_COL_08_B = 'disk_usage'
MONGO_COL_08_C = 'ram_usage'

# Firebase
FIREBASE_ANDROID_CERT_DIR = 'C:\\Users\\PligenceUser\\Videos\\pda-cms-backend-django\\core\\firebase-android-certificate.json'
FIREBASE_IOS_CERT_DIR = 'C:\\Users\\PligenceUser\\Videos\\pda-cms-backend-django\\core\\firebase-ios-certificate.json'
