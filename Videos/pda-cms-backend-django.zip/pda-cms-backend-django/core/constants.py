SENSOR_MAPPING = {
    1: 'Camera',
    2: 'Microphone',
    3: 'GPS',
    4: 'Call',
    5: 'SMS',
    6: 'None'
}
