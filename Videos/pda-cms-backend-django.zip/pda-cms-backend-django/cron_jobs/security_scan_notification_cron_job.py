from core import secrets
from api.broadcast.services import android_firebase
from api.broadcast.services import get_tokens
from utils.util import chunkify
from firebase_admin import messaging
from datetime import datetime
from utils import mongo
from utils.logger import logger


if __name__ == "__main__":
    # Checking if firebase app is initialized or not
    # if 'android_firebase' not in firebase_admin._apps:
    #     android_cred = credentials.Certificate(secrets.ANDROID_FIREBASE_CERT_DIR)
    #     android_firebase = firebase_admin.initialize_app(android_cred, name="android_firebase")

    title = "Scan Phone Now"
    body = "To ensure the privacy and security, it is recommended to perform security scan periodically.\n \
               To perform the security scan open Privacy Defender and tap “Scan Now”."
    action = "security_scan"

    security_scan_payload = {"title": title,
                             "message": body,
                             "action": action,
                             "timestamp": datetime.utcnow().isoformat(),
                             "is_broadcast": "false"}

    tokens, ios_tokens = get_tokens(filters={})

    tokens = [token for token in tokens if token]
    # MulticastMessage allows a maximum of 500 tokens per message. We divide all out tokens into chunks of 500 and send
    # message to each chunk one by one
    chunks = chunkify(tokens, 500)
    result = {'success_count': 0, 'failure_count': 0, 'total_count': len(tokens)}
    for chunk in chunks:
        try:
            message = messaging.MulticastMessage(data=security_scan_payload, tokens=chunk)
            response = messaging.send_multicast(message, app=android_firebase)
            result['success_count'] += response.success_count
            result['failure_count'] += response.failure_count
        except Exception as err:
            result['failure_count'] += len(chunk)
            print(f'Failed to send broadcast. Error: {str(err)}')

    # Inserting Notification Object Into Mongo DB
    document = {
        'title': title,
        'message': body,
        'action': action,
        'sent_at': datetime.utcnow(),
        'success_count': result.get('success_count'),
        'failure_count': result.get('failure_count'),
        'total_count': result.get('total_count')}

    try:
        col = secrets.MONGO_COL_03_E
        conn = mongo.get_collection(db=secrets.MONGO_DB_03, col=col)
        conn.insert_one(document)
    except Exception as err:
        logger.error(f'Failed to save broadcast. Error: {str(err)}')

    print(f"Successfully sent to {result['success_count']}/{result['total_count']} users")
    print(f"Failed notification count: {result['failure_count']}")
