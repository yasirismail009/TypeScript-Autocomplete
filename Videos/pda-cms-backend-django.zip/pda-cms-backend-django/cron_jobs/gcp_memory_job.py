import os
from datetime import datetime

import psutil

from core import secrets, settings
from utils import mongo


def conv_KB_to_GB(b):
    if b < 1000:
        return '%i' % b + 'B'
    elif 1000 <= b < 1000000:
        return '%.1f' % float(b / 1000) + 'KB'
    elif 1000000 <= b < 1000000000:
        return '%.1f' % float(b / 1000000) + 'MB'
    elif 1000000000 <= b < 1000000000000:
        return '%.1f' % float(b / 1000000000) + 'GB'
    elif 1000000000000 <= b:
        return '%.1f' % float(b / 1000000000000) + 'TB'


check_time = datetime.utcnow()
# Cpu Ram Stats
system_ram_pecentage = psutil.virtual_memory()[2]
system_ram_free = conv_KB_to_GB(psutil.virtual_memory()[4])
system_ram_used = conv_KB_to_GB(psutil.virtual_memory()[3])
system_ram_total = conv_KB_to_GB(psutil.virtual_memory()[0])
system_ram = {
    'system_ram_total': system_ram_total,
    'system_ram_used': system_ram_used,
    'system_ram_free': system_ram_free,
    'system_ram_pecentage': system_ram_pecentage,
    'time_added': check_time

}
# Disk Usage Stats
disk_usage_pecentage = psutil.disk_usage('/')[3]
disk_usage_free = conv_KB_to_GB(psutil.disk_usage('/')[2])
disk_usage_used = conv_KB_to_GB(psutil.disk_usage('/')[1])
disk_usage_total = conv_KB_to_GB(psutil.disk_usage('/')[0])
disk_usage = {
    'disk_usage_total': disk_usage_total,
    'disk_usage_used': disk_usage_used,
    'disk_usage_free': disk_usage_free,
    'disk_usage_pecentage': disk_usage_pecentage,
    'time_added': check_time

}
# Cpu Usage Stats
print(psutil.cpu_stats())
cpu_ctx_switches = conv_KB_to_GB(psutil.cpu_stats()[0])
cpu_interrupts = conv_KB_to_GB(psutil.cpu_stats()[1])
cpu_soft_interrupts = conv_KB_to_GB(psutil.cpu_stats()[2])
cpu_syscalls = conv_KB_to_GB(psutil.cpu_stats()[3])
cpu_usage = {
    'cpu_ctx_switches': cpu_ctx_switches,
    'cpu_interrupts': cpu_interrupts,
    'cpu_soft_interrupts': cpu_soft_interrupts,
    'cpu_syscalls': cpu_syscalls,
    'time_added': check_time

}

# conn = mongo.get_collection2(db=secrets.MONGO_DB_20, col=secrets.MONGO_DB_20_A)
# conn1 = mongo.get_collection2(db=secrets.MONGO_DB_20, col=secrets.MONGO_DB_20_B)
# conn2 = mongo.get_collection2(db=secrets.MONGO_DB_20, col=secrets.MONGO_DB_20_C)
# result = conn.insert(cpu_usage)
# result1 = conn1.insert(disk_usage)
# result2 = conn2.insert(system_ram)

print("The Ram usage is : ", system_ram)
print("The Disk usage is : ", disk_usage)
print("The Cpu usage is : ", cpu_usage)
