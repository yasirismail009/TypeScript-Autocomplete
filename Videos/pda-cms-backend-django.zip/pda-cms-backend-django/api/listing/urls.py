from django.urls import path
from api.listing import views

urlpatterns = [
    path('suspicious-apps/', views.suspicious_apps),
    path('whitelisted-apps/', views.whitelisted_apps),
    path('whitelisted-suspicious-apps/', views.whitelisted_suspicious_apps),
    path('verified-app-sources/', views.verified_app_sources),
    path('dangerous-permissions/', views.dangerous_permissions),
    path('firewall-rules/', views.firewall_rules),
    path('user-installed-malicious-apps/', views.user_installed_malicious_apps),
    path('user-installed-suspicious-apps/', views.user_installed_suspicious_apps),
    path('user-hit-malicious-hosts/', views.user_hit_malicious_hosts),
    path('systemd-services/', views.systemd_services),
    path('pda-version/', views.pda_version),
    path('pda-user/', views.pda_user),
    path('announcement-listing/', views.pda_announcement_listing),
    path('news-listing/', views.pda_news_listing),
    path('security-scan-listing/', views.pda_security_scan_listing),
    path('listing-search/', views.listing_search),
]
