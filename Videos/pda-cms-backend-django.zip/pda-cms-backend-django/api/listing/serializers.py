from datetime import date
from rest_framework.serializers import Serializer, CharField, IntegerField


class PackageName(Serializer):
    package_name = CharField(required=True)
    category = CharField(max_length=512, required=True)
    page= IntegerField(max_value=100, required=True)
