import traceback

from rest_framework.decorators import api_view, authentication_classes, permission_classes

from api.listing import services
from utils.util import validate_page_number
from api.listing.serializers import PackageName
from utils.responses import ok, bad_request, internal_server_error, created, not_found


@api_view(['GET'])
def suspicious_apps(request):
    try:
        page = validate_page_number(request.query_params.get('page', 1))

        data = services.get_suspicious_apps(page)

        return ok(data=data)

    except Exception:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to get apps')


@api_view(['GET'])
def whitelisted_apps(request):
    try:
        page = validate_page_number(request.query_params.get('page', 1))

        data = services.get_whitelisted_apps(page)

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get apps')


@api_view(['GET'])
def whitelisted_suspicious_apps(request):
    try:
        page = validate_page_number(request.query_params.get('page', 1))

        data = services.get_whitelisted_suspicious_apps(page)

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get apps')


@api_view(['GET'])
def verified_app_sources(request):
    try:
        page = validate_page_number(request.query_params.get('page', 1))

        data = services.get_verified_app_sources(page)

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get sources')


@api_view(['GET'])
def dangerous_permissions(request):
    try:
        page = validate_page_number(request.query_params.get('page', 1))

        data = services.get_dangerous_permissions(page)

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get permissions')


@api_view(['GET'])
def firewall_rules(request):
    try:
        page = validate_page_number(request.query_params.get('page', 1))

        data = services.get_firewall_rules(page)

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get rules')


@api_view(['GET'])
def user_installed_malicious_apps(request):
    try:
        page = validate_page_number(request.query_params.get('page', 1))

        data = services.get_user_installed_malicious_apps(page)

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get apps')


@api_view(['GET'])
def user_installed_suspicious_apps(request):
    try:
        page = validate_page_number(request.query_params.get('page', 1))

        data = services.get_user_installed_suspicious_apps(page)

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get apps')


@api_view(['GET'])
def user_hit_malicious_hosts(request):
    try:
        page = validate_page_number(request.query_params.get('page', 1))

        data = services.get_user_hit_malicious_hosts(page)

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get hosts')


@api_view(['GET'])
def systemd_services(request):
    try:
        data = services.get_systemd_services()

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get services')


@api_view(['GET'])
def pda_version(request):
    try:

        data = services.get_pda_version()

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get version')


@api_view(['GET'])
@authentication_classes([])
@permission_classes([])
def pda_user(request):
    try:
        page = validate_page_number(request.query_params.get('page', 1))
        data = services.get_pda_user(page)

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get users')


@api_view(['GET'])
def pda_announcement_listing(request):
    try:
        page = validate_page_number(request.query_params.get('page', 1))
        data = services.get_pda_announcement_listing(page)

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get users')


@api_view(['GET'])
def pda_news_listing(request):
    try:
        page = validate_page_number(request.query_params.get('page', 1))
        data = services.get_pda_news_listing(page)

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get users')


@api_view(['GET'])
def pda_security_scan_listing(request):
    try:
        page = validate_page_number(request.query_params.get('page', 1))
        data = services.get_pda_security_scan_listing(page)

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get users')


@api_view(['POST'])
def listing_search(request):
    try:
        print(request.data)
        serializer = PackageName(data=request.data)
        if not serializer.is_valid():
            return bad_request(data=serializer.errors)
        package_name = serializer.validated_data.get('package_name')
        category = serializer.validated_data.get('category')
        page = serializer.validated_data.get('page')
        data = services.get_search_listing(package_name, category, page)

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get users')
