import pymongo
import json
from bson.json_util import dumps, loads
from psycopg2 import sql

from utils import mongo, postgres
from core import secrets, settings


def get_suspicious_apps(page):
    skip = (page - 1) * settings.PER_PAGE_25
    conn = mongo.get_collection(db=secrets.MONGO_DB_04, col=secrets.MONGO_COL_04_A)

    count = conn.count_documents({})
    cursor = conn.find({}, {'_id': 0, 'app_package_name': 1, 'app_name': '$app_name',
                            'app_version_name': '$app_version_name',
                            'app_version_code': '$app_version_code', 'app_source': '$app_source', 'app_uid': '$app_uid',
                            'suspicious_declared_at': '$suspicious_declared_at', 'permissions': '$permissions',
                            'app_package_version_hkey': '$app_package_version_hkey'}).sort('suspicious_declared_at',
                                                                                           pymongo.DESCENDING).skip(
        skip).limit(
        settings.PER_PAGE_25)

    apps = loads(dumps(cursor))

    for ele in apps:
        permission = []
        for x in ele['permissions']:
            permission.append({'permission': x})
            ele['permissions'] = permission

    data = {
        'list': apps,
        'count': count
    }

    return data


def get_whitelisted_apps(page):
    skip = (page - 1) * settings.PER_PAGE_25
    conn = mongo.get_collection(db=secrets.MONGO_DB_05, col=secrets.MONGO_COL_05_A)

    count = conn.count_documents({})
    cursor = conn \
        .find({}, {'_id': 0, 'loaded': 0, 'date_extracted_at': 0}) \
        .sort('_id', pymongo.DESCENDING) \
        .skip(skip) \
        .limit(settings.PER_PAGE_25)

    apps = loads(dumps(cursor))

    data = {
        'list': apps,
        'count': count
    }

    return data


def get_whitelisted_suspicious_apps(page):
    skip = (page - 1) * settings.PER_PAGE_25
    conn = mongo.get_collection(db=secrets.MONGO_DB_06, col=secrets.MONGO_COL_06_A)

    count = conn.count_documents({})
    cursor = conn.find({}, {'_id': 0}).skip(skip).limit(settings.PER_PAGE_25)

    apps = loads(dumps(cursor))

    data = {
        'list': apps,
        'count': count
    }

    return data


def get_verified_app_sources(page):
    skip = (page - 1) * settings.PER_PAGE_25
    conn = mongo.get_collection(db=secrets.MONGO_DB_06, col=secrets.MONGO_COL_06_B)

    count = conn.count_documents({})
    cursor = conn.find({}, {'_id': 0}).skip(skip).limit(settings.PER_PAGE_25)

    sources = loads(dumps(cursor))

    data = {
        'list': sources,
        'count': count
    }

    return data


def get_dangerous_permissions(page):
    skip = (page - 1) * settings.PER_PAGE_25
    conn = mongo.get_collection(db=secrets.MONGO_DB_06, col=secrets.MONGO_COL_06_C)

    count = conn.count_documents({})
    cursor = conn.find({}, {'_id': 0}).skip(skip).limit(settings.PER_PAGE_25)

    permssions = loads(dumps(cursor))

    data = {
        'list': permssions,
        'count': count
    }

    return data


def get_firewall_rules(page):
    skip = (page - 1) * settings.PER_PAGE_25
    conn = mongo.get_collection(db=secrets.MONGO_DB_07, col=secrets.MONGO_COL_07_A)

    count = conn.count_documents({})
    cursor = conn \
        .find({}, {'_id': 0, 'loaded': 0, 'timestamp': 0, 'kafka_offset': 0}) \
        .sort('timestamp', pymongo.DESCENDING) \
        .skip(skip) \
        .limit(settings.PER_PAGE_25)

    rules = loads(dumps(cursor))

    data = {
        'list': rules,
        'count': count
    }

    return data


def get_user_installed_malicious_apps(page):
    skip = (page - 1) * settings.PER_PAGE_25

    conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_C)
    count = conn.count_documents({'app_response_key': 1})
    cursor = conn.find({'app_response_key': 1},
                       {'_id': 0, 'app_package_name': 1, 'user_key': '$user_key', 'app_source': '$app_source',
                        'app_package_version_hkey': '$app_package_version_hkey', 'app_category': '$app_category'}).sort(
        '_id', pymongo.DESCENDING).skip(
        skip).limit(
        settings.PER_PAGE_25)

    apps = loads(dumps(cursor))

    data = {
        'list': apps,
        'count': count
    }

    return data


def get_user_installed_suspicious_apps(page):
    skip = (page - 1) * settings.PER_PAGE_25

    conn = mongo.get_collection(db=secrets.MONGO_DB_02, col=secrets.MONGO_COL_02_B)
    count = conn.count_documents({})
    cursor = conn.find({}, {'_id': 0, 'app_package_name': 1, 'user_key': "$user_key", 'app_name': "$app_name",
                            'app_version_name': "$app_version_name",
                            'app_version_code': "$app_version_code", }).sort('_id', pymongo.DESCENDING).skip(
        skip).limit(
        settings.PER_PAGE_25)

    apps = loads(dumps(cursor))

    data = {
        'list': apps,
        'count': count
    }

    return data


def get_user_hit_malicious_hosts(page):
    skip = (page - 1) * settings.PER_PAGE_25

    conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_B)
    count = conn.count_documents({"host_response_key": 1})
    cursor = conn.find({"host_response_key": 1},
                       {'_id': 0, 'app_package_name': 1, 'host_address': '$host_address', 'user_key': '$user_key',
                        'app_package_version_hkey': '$app_package_version_hkey',
                        'host_hashed_key': '$host_hashed_key', 'ad_network': '$ad_network', 'is_adult': '$is_adult',
                        'host_category': '$host_category', }).sort(
        '_id', pymongo.DESCENDING).skip(skip).limit(
        settings.PER_PAGE_25)

    hosts = loads(dumps(cursor))

    data = {
        'list': hosts,
        'count': count
    }

    return data


def get_systemd_services():
    query = sql.SQL(
        'SELECT table_name FROM information_schema.tables WHERE table_schema=\'public\' AND table_type=\'BASE TABLE\'')
    conn = postgres.Connection(
        host=secrets.PSQL_HOST_02,
        port=secrets.PSQL_PORT_02,
        user=secrets.PSQL_USER_02,
        password=secrets.PSQL_PSWD_02,
        db=secrets.PSQL_DB_02
    )
    # See the main query with `print(query.as_string(context=conn.connection))`
    result = conn.fetch_all(query)

    services = [_service for (_service,) in result]
    count = len(services)

    data = {
        'list': services,
        'count': count
    }

    return data


def get_pda_version():
    query = sql.SQL(
        'SELECT pda_version,count(*) FROM public.user GROUP  BY pda_version')
    conn = postgres.Connection(
        host=secrets.PSQL_HOST,
        port=secrets.PSQL_PORT,
        user=secrets.PSQL_USER,
        password=secrets.PSQL_PSWD,
        db=secrets.PSQL_DB_01
    )
    # See the main query with `print(query.as_string(context=conn.connection))`
    result = conn.fetch_all(query)
    listing = []
    for services in result:
        listing.append({"version": services[0], "count": services[1]})

    return listing


def get_pda_user(page):
    skip = (page - 1) * settings.PER_PAGE_10

    query = sql.SQL(
        f'SELECT  date(date_joined) as dt,count(*) FROM public.user GROUP  BY date(date_joined) order by dt desc LIMIT 10 OFFSET {skip} ')
    conn = postgres.Connection(
        host=secrets.PSQL_HOST,
        port=secrets.PSQL_PORT,
        user=secrets.PSQL_USER,
        password=secrets.PSQL_PSWD,
        db=secrets.PSQL_DB_01
    )
    # See the main query with `print(query.as_string(context=conn.connection))`
    result = conn.fetch_all(query)
    listing = []
    for services in result:
        listing.append({"date": services[0], "count": services[1]})

    return listing


def get_pda_announcement_listing(page):
    skip = (page - 1) * settings.PER_PAGE_10
    conn = mongo.get_collection(db=secrets.MONGO_DB_03, col=secrets.MONGO_COL_03_B)
    count = conn.count_documents({})
    cursor = conn.find({},
                       {'_id': 0, 'filters': 0, 'false_positive_list': 0, }).sort(
        '_id', pymongo.DESCENDING).skip(skip).limit(
        settings.PER_PAGE_10)

    hosts = loads(dumps(cursor))

    data = {
        'list': hosts,
        'count': count
    }
    return data


def get_pda_news_listing(page):
    skip = (page - 1) * settings.PER_PAGE_10
    conn = mongo.get_collection(db=secrets.MONGO_DB_03, col=secrets.MONGO_COL_03_A)
    count = conn.count_documents({})
    cursor = conn.find({},
                       {'_id': 0, 'filters': 0, }).sort(
        '_id', pymongo.DESCENDING).skip(skip).limit(
        settings.PER_PAGE_10)

    hosts = loads(dumps(cursor))

    data = {
        'list': hosts,
        'count': count
    }
    return data


def get_pda_security_scan_listing(page):
    skip = (page - 1) * settings.PER_PAGE_10
    conn = mongo.get_collection(db=secrets.MONGO_DB_03, col=secrets.MONGO_COL_03_E)
    count = conn.count_documents({})
    cursor = conn.find({},
                       {'_id': 0, 'filters': 0, }).sort(
        '_id', pymongo.DESCENDING).skip(skip).limit(
        settings.PER_PAGE_10)

    hosts = loads(dumps(cursor))

    data = {
        'list': hosts,
        'count': count
    }
    return data


def get_search_listing(package_name, category, page):
    skip = (page - 1) * settings.PER_PAGE_25
    if category == "whitelisted-apps":
        conn = mongo.get_collection(db=secrets.MONGO_DB_05, col=secrets.MONGO_COL_05_A)
        count = conn.count_documents({"app_package_name": package_name})
        cursor = conn.find({"app_package_name": package_name}, {'_id': 0, 'loaded': 0, 'date_extracted_at': 0}).sort(
            '_id', pymongo.DESCENDING).skip(skip).limit(
            settings.PER_PAGE_25)
    elif category == "whitelisted-suspicious-apps":
        conn = mongo.get_collection(db=secrets.MONGO_DB_06, col=secrets.MONGO_COL_06_A)
        count = conn.count_documents({"app_package_name": package_name})
        cursor = conn.find({"app_package_name": package_name}, {'_id': 0}).sort(
            '_id', pymongo.DESCENDING).skip(skip).limit(
            settings.PER_PAGE_25)
    elif category == "suspicious-apps":
        conn = mongo.get_collection(db=secrets.MONGO_DB_04, col=secrets.MONGO_COL_04_A)
        count = conn.count_documents({"app_package_name": package_name})
        cursor = conn.find({"app_package_name": package_name},
                           {'_id': 0, 'suspicious_declared_at': 0, 'permissions': 0}).sort(
            '_id', pymongo.DESCENDING).skip(skip).limit(
            settings.PER_PAGE_25)
    elif category == "verified-app-sources":
        conn = mongo.get_collection(db=secrets.MONGO_DB_06, col=secrets.MONGO_COL_06_B)
        count = conn.count_documents({"app_source": package_name})
        cursor = conn.find({"app_source": package_name}, {'_id': 0}).sort(
            '_id', pymongo.DESCENDING).skip(skip).limit(
            settings.PER_PAGE_25)
    elif category == "dangerous-permissions":
        conn = mongo.get_collection(db=secrets.MONGO_DB_06, col=secrets.MONGO_COL_06_C)
        count = conn.count_documents({"permission": package_name})
        cursor = conn.find({"permission": package_name}, {'_id': 0}).sort(
            '_id', pymongo.DESCENDING).skip(skip).limit(
            settings.PER_PAGE_25)
    elif category == "firewall-rules":
        conn = mongo.get_collection(db=secrets.MONGO_DB_07, col=secrets.MONGO_COL_07_A)
        count = conn.count_documents({"host_address": package_name})
        cursor = conn.find({"host_address": package_name}, {'_id': 0, 'loaded': 0, 'timestamp': 0}).sort(
            '_id', pymongo.DESCENDING).skip(skip).limit(
            settings.PER_PAGE_25)
    elif category == "user-installed-malicious-apps":
        conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_C)
        count = conn.count_documents({"app_package_name": package_name})
        cursor = conn.find({"app_package_name": package_name}, {'_id': 0}).sort(
            '_id', pymongo.DESCENDING).skip(skip).limit(
            settings.PER_PAGE_25)
    elif category == "user-installed-suspicious-apps":
        conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_C)
        count = conn.count_documents({"app_package_name": package_name})
        cursor = conn.find({"app_package_name": package_name}, {'_id': 0}).sort(
            '_id', pymongo.DESCENDING).skip(skip).limit(
            settings.PER_PAGE_25)
    elif category == "user-hit-malicious-hosts":
        conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_B)
        count = conn.count_documents({"host_address": package_name, "host_response_key": 1})
        cursor = conn.find({"host_address": package_name, "host_response_key": 1},
                           {'_id': 0, 'device_key': 0, 'event_date': 0, 'event_time': 0, 'app_name': 0,
                            'app_version_name': 0, 'app_version_code': 0, 'app_source': 0, 'app_uid': 0,
                            'location_chkey': 0, 'is_use_case_checked': 0, 'event_key': 0, 'is_loaded_into_pgsql': 0,
                            'loaded': 0, 'app_category_chkey': 0, 'app_category': 0, 'app_sub_category': 0,
                            'app_response_key': 0, 'app_traffic': 0, 'host_sub_category': 0, 'kafka_offset': 0,
                            'host_category_chkey': 0}).sort(
            '_id', pymongo.DESCENDING).skip(skip).limit(
            settings.PER_PAGE_25)

    hosts = json.loads(dumps(cursor))
    data = {
        'list': hosts,
        'count': count
    }
    return data
