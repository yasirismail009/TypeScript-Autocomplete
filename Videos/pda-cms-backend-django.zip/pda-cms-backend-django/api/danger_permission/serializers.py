from datetime import date
from rest_framework.serializers import CharField, Serializer


class DangerpermissionSerializer(Serializer):
    permission = CharField(max_length=512, required=True)


class EditDangerpermissionSerializer(Serializer):
    update = CharField(max_length=512, required=True)
    permission = CharField(max_length=512, required=True)