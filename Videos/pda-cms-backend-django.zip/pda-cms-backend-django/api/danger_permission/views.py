
from django.core.paginator import Paginator
from rest_framework.decorators import api_view, permission_classes, authentication_classes
from rest_framework.views import APIView

from api.apps import services


from api.danger_permission.serializers import DangerpermissionSerializer, EditDangerpermissionSerializer
from core import secrets
from core.secrets import MONGO_DB_06, MONGO_COL_06_C
from utils import mongo
from utils.responses import ok, bad_request, internal_server_error, created, not_found
from utils.mongo import get_collection
import traceback

class DangerPermissionsApi(APIView):
    def post(self, request):
        try:
            serializer = DangerpermissionSerializer(data=request.data)

            if not serializer.is_valid():
                return bad_request(data=serializer.errors, message='Failed to create Danger Permission')

            danger_permission_instance = serializer.validated_data
            mongo_collection = mongo.get_collection(db=secrets.MONGO_DB_06, col=secrets.MONGO_COL_06_C)
            mongo_collection.insert_one(dict(danger_permission_instance))
            return created(data={'permission': danger_permission_instance.get('permission')}, message='Danger Permission created successfully')

        except Exception as err:
            print(err)
            return internal_server_error(message='Failed to create Danger Permission')

    def get(self, request, danger_permission):
        try:
            serializer = DangerpermissionSerializer(danger_permission)
            mongo_collection = mongo.get_collection(db=secrets.MONGO_DB_06, col=secrets.MONGO_COL_06_C)
            query = {"permission": danger_permission}
            projection = {"_id": 0}
            danger_permission_instance =list(mongo_collection.find_one(query, projection))

            return ok(data={'danger_permission': danger_permission_instance})

        except Exception as err:
            print(err)
            return internal_server_error(message='Failed to get Danger Permission')

    def patch(self, request):
        try:
            serializer = EditDangerpermissionSerializer(data=request.data)
            if not serializer.is_valid():
                return bad_request(data=serializer.errors, message='Failed to update Danger Permission')
            updated_danger_permission_instance = serializer.validated_data
            mongo_collection = mongo.get_collection(db=secrets.MONGO_DB_06, col=secrets.MONGO_COL_06_C)
            query = {"permission": updated_danger_permission_instance.get("permission")}
            mongo_collection.update_one(query, {"$set": {"permission": updated_danger_permission_instance.get("update")}})

            return ok(data={'updated_danger_permission': updated_danger_permission_instance.get("update")}, message='Danger Permission updated successfully')

        except Exception as err:
            print(err)
            return internal_server_error(message='Failed to update Danger Permission')

    def delete(self, request):
        try:
            print(request.data)
            serializer = DangerpermissionSerializer(data=request.data)
            if not serializer.is_valid():
                return bad_request(data=serializer.errors, message='Failed to delete Danger Permission')
            delete_danger_permission_instance = serializer.validated_data
            mongo_collection = mongo.get_collection(db=secrets.MONGO_DB_06, col=secrets.MONGO_COL_06_C)
            query = {"permission": delete_danger_permission_instance.get("permission")}
            mongo_collection.delete_one(query)
            return ok(message='Danger Permission deleted successfully')

        except Exception as err:
            print(err)
            return internal_server_error(message='Failed to delete Danger Permission')


@api_view(['GET'])
def app_danger_permissions_listing(request):
    try:
        conn = mongo.get_collection(db=secrets.MONGO_DB_06, col=secrets.MONGO_COL_06_C)
        danger_permission_records = list(conn.find({}, {"_id": 0}))
        return ok(data={'danger_permission': danger_permission_records, 'count': len(danger_permission_records)})

    except Exception:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to get export data')
