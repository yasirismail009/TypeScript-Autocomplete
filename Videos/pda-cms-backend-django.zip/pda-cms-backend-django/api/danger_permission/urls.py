from django.urls import path
from api.danger_permission import views

urlpatterns = [
    path('app-danger-permissions-listing/', views.app_danger_permissions_listing),
    path('', views.DangerPermissionsApi.as_view()),

]
