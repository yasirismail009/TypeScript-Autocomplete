from bson.json_util import dumps, loads
from psycopg2 import sql

from utils import mongo, util, postgres
from core import secrets, constants
import datetime
from datetime import timedelta
import calendar


def total_danger_permissions(package_name):


    conn = mongo.get_collection(db=secrets.MONGO_DB_06, col=secrets.MONGO_COL_06_C)

    query_danger_permissions = [{"$match": {"app_package_name": package_name}},
                        {"$group": {"_id": {"user_key": "$user_key"}}},
                        {"$group": {"_id": "number_of_user_using_app", "count": {"$sum": 1}}}]

    app_total_user = list(conn.aggregate(query_total_user))



    return {
        'user_total_count': app_total_user,

    }
