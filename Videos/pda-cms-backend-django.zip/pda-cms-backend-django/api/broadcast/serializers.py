from datetime import date
from rest_framework.serializers import Serializer, CharField, ValidationError, BooleanField, DateField, ListField


valid_platforms = ['app_gallery', 'app_store', 'play_store']
valid_host_types = ['domain', 'ip', 'url']
# valid_actions = ['news', 'announcement', 'false_positive', 'announcement_external_link', 'security_scan']
#
#
# def validate_action(value):
#     if value not in valid_actions:
#         raise ValidationError('Not a valid action.')


def validate_platform(values):
    if not values:
        raise ValidationError(f'This field cannot be empty.')
    for value in values:
        if value not in valid_platforms:
            raise ValidationError(f'\'{value}\' is not a valid platform.')


class DateJoinedSerializer(Serializer):
    after = DateField(required=True)
    before = DateField(required=True)

    def validate(self, data):
        if data['after'] > data['before']:
            raise ValidationError({'after': 'Start date must come before the end date.'})
        if data['before'] > date.today():
            raise ValidationError({'before': 'End date cannot be in the future.'})
        return data


class HasAppSerializer(Serializer):
    apk_hash = CharField(required=False)
    app_name = CharField(required=False)
    app_package_name = CharField(required=False)
    app_version_code = CharField(required=False)
    app_version_name = CharField(required=False)

    def validate(self, data):
        if 'apk_hash' not in data and 'app_package_name' not in data:
            raise ValidationError('Provide at least \'apk_hash\' or \'app_package_name\'.')

        if 'apk_hash' in data and 'app_package_name' in data:
            raise ValidationError(
                '\'apk_hash\' and \'app_package_name\' cannot be provided together. Only one is allowed at a time.')
        return data


class UsersFilter(Serializer):
    date_joined = DateJoinedSerializer(required=False)
    platform = ListField(validators=[validate_platform], required=False)
    has_subscription = BooleanField(required=False)
    has_app = HasAppSerializer(required=False)


class SendBroadcastSerializer(Serializer):
    title = CharField(max_length=255, min_length=4, required=True)
    message = CharField(max_length=2047, min_length=4, required=True)
    # action = CharField(required=True, validators=[validate_action])
    action = CharField(required=True)
    users_filter = UsersFilter(required=True)


class NewsBroadcastSerializer(SendBroadcastSerializer):
    def validate(self, data):
        if data.get('action') != 'news':
            raise ValidationError(f'Not a valid action.')

        return data


class AnnouncementBroadcastSerializer(SendBroadcastSerializer):
    def validate(self, data):
        if data.get('action') != 'announcement':
            raise ValidationError(f'Not a valid action.')

        return data


class FalsePositiveHostBroadcastSerializer(SendBroadcastSerializer):
    host_type = CharField(max_length=20, required=True)
    false_positive_list = ListField(required=True)

    def validate(self, data):
        if not data.get('false_positive_list'):
            raise ValidationError(f'This field cannot be empty.')

        if data.get('action') != 'false_positive_host':
            raise ValidationError(f'Not a valid action.')

        if data.get('host_type') not in valid_host_types:
            raise ValidationError(f'Not a valid host type.')

        for false_positive in data.get('false_positive_list'):
            if not isinstance(false_positive, str):
                raise ValidationError(f'False Positive List can only contain strings.')

        return data


class FalsePositiveAppBroadcastSerializer(SendBroadcastSerializer):
    app_name = CharField(max_length=255, required=True)
    app_package_name = CharField(max_length=255, required=True)
    app_version_name = CharField(max_length=255, required=True)
    app_version_code = CharField(max_length=255, required=True)

    def validate(self, data):
        if data.get('action') != 'false_positive_app':
            raise ValidationError(f'Not a valid action.')

        return data


class AnnouncementExternalLinkBroadcastSerializer(SendBroadcastSerializer):
    url = CharField(max_length=2047, required=True)

    def validate(self, data):
        if data.get('action') != 'announcement_external_link':
            raise ValidationError(f'Not a valid action.')

        return data
