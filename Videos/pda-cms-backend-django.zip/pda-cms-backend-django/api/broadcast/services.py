import json
import firebase_admin
from psycopg2 import sql
from datetime import datetime
from firebase_admin import credentials, messaging
from bson.json_util import dumps
from core import secrets
from utils import postgres, mongo, util
from utils.logger import logger

# Android firebase app to send notifications
android_cred = credentials.Certificate(secrets.FIREBASE_ANDROID_CERT_DIR)
android_firebase = firebase_admin.initialize_app(android_cred, name="android_firebase")

# Ios firebase app to send notifications
ios_cred = credentials.Certificate(secrets.FIREBASE_IOS_CERT_DIR)
ios_firebase = firebase_admin.initialize_app(ios_cred, name="ios_firebase")


action_to_collection_mapping = {
    'news': secrets.MONGO_COL_03_A,
    'announcement': secrets.MONGO_COL_03_B,
    'false_positive': secrets.MONGO_COL_03_C,
    'announcement_external_link': secrets.MONGO_COL_03_D,
    'security_scan': secrets.MONGO_COL_03_E,
}


def get_ids_of_users_with_app(app_details):
    app_name = app_details.get('app_name', None)
    app_package_name = app_details.get('app_package_name', None)
    app_version_code = app_details.get('app_version_code', None)
    app_version_name = app_details.get('app_version_name', None)
    apk_hash = app_details.get('apk_hash', None)

    conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_C)
    cursor = None

    # There can be 2 scenarios when searching for users with a specific app:
    # 1. App's APK file hash (apk_hash) is provided. In this case, search the database for all documents containing
    #    this file hash
    # 2. Other app details (name, version etc.) are provided. In this case, there are further 2 possibilities:
    #    a: ALL 4 app details (app_name, app_package_name, app_version_code, app_version_name) are provided. If so, we
    #       generate an MD5 hash of the details and search the database for all documents containing this hash
    #    b: SOME app details are provided. In this case, we build a query based on what details have been given and then
    #       search the database

    # Scenario 1
    if apk_hash:
        cursor = conn.find({'apk_hash': app_details.get('apk_hash')}, {'_id': 0, 'user_key': 1})
    # Scenario 2
    elif app_package_name:
        # Scenario 2.a
        if app_name and app_version_code and app_version_name:
            concatenated_string = app_name + app_package_name + app_version_code + app_version_name  # Order is important here
            md5_hash = util.md5(concatenated_string)
            cursor = conn.find({'app_package_version_hkey': md5_hash}, {'_id': 0, 'user_key': 1})
        # Scenario 2.b
        else:
            query = {'app_package_name': app_package_name}  # `app_package_name` will always be provided
            if 'app_name' in app_details:
                query['app_name'] = app_name
            if 'app_version_code' in app_details:
                query['app_version_code'] = app_version_code
            if 'app_version_name' in app_details:
                query['app_version_name'] = app_version_name

            cursor = conn.find(query, {'_id': 0, 'user_key': 1})

    result = json.loads(dumps(cursor))
    ids = list(set([d['user_key'] for d in result]))  # Remove duplicates and flatten
    return ids


def get_tokens(filters: dict):
    # Build the SQL query section by section, based on the filters
    sections = []
    s1 = sql.SQL('SELECT DISTINCT(firebase_token),store FROM {table} WHERE firebase_token IS NOT NULL').format(
        table=sql.Identifier(secrets.PSQL_SCH_01_A, secrets.PSQL_TAB_01_A))
    sections.append(s1)

    if 'platform' in filters:
        s2 = sql.SQL('AND store IN ({platforms})').format(
            platforms=sql.SQL(',').join([sql.Literal(value) for value in filters.get('platform')]))
        sections.append(s2)

    if 'date_joined' in filters:
        s3 = sql.SQL('AND Date(date_joined) >= {after} AND Date(date_joined) <= {before}').format(
            after=sql.Literal(filters.get('date_joined').get('after')),
            before=sql.Literal(filters.get('date_joined').get('before')))
        sections.append(s3)

    if 'has_app' in filters:
        app_details = filters.get('has_app')
        ids = get_ids_of_users_with_app(app_details)

        # If `ids` is empty that means no user has the given app installed. Hence, no user needs to recieve the
        # notification. We can return an empty array of tokens (as an early bail) instead of building and executing
        # the SQL query
        if not ids:
            return [], []

        s4 = sql.SQL('AND id IN ({ids})').format(ids=sql.SQL(',').join([sql.Literal(value) for value in ids]))
        sections.append(s4)

    conn = postgres.Connection(db=secrets.PSQL_DB_01)
    query = sql.SQL(' ').join(sections)
    # See the main query with `print(query.as_string(context=conn.connection))`
    result = conn.fetch_all(query)
    ios_tokens = []

    tokens = [token if store != "app_store" else ios_tokens.append(token) for (token, store) in result]
    return tokens, ios_tokens


def send_broadcast(data: dict, filters: dict):
    data['timestamp'] = datetime.utcnow().isoformat()
    data['is_broadcast'] = 'false'

    android_tokens, ios_tokens = get_tokens(filters=filters)
    result = {'success_count': 0, 'failure_count': 0, 'total_count': len(android_tokens)}

    # MulticastMessage allows a maxinum of 500 tokens per message. We divide all out tokens into chunks of 500 and send
    # message to each chunk one by one
    chunks = util.chunkify(ios_tokens, 500)
    # result = {'success_count': 0, 'failure_count': 0, 'total_count': len(ios_tokens)}
    result["total_count"] += len(ios_tokens)
    for chunk in chunks:
        try:
            message = messaging.MulticastMessage(data=data, tokens=chunk)
            response = messaging.send_multicast(message, app=ios_firebase)
            result['success_count'] += response.success_count
            result['failure_count'] += response.failure_count
        except Exception as err:
            result['failure_count'] += len(chunk)
            logger.error(f'Failed to send broadcast. Error: {str(err)}')

    # MulticastMessage allows a maxinum of 500 tokens per message. We divide all out tokens into chunks of 500 and send
    # message to each chunk one by one
    chunks = util.chunkify(android_tokens, 500)

    for chunk in chunks:
        try:
            message = messaging.MulticastMessage(data=data, tokens=chunk)
            response = messaging.send_multicast(message, app=android_firebase)
            result['success_count'] += response.success_count
            result['failure_count'] += response.failure_count
        except Exception as err:
            result['failure_count'] += len(chunk)
            logger.error(f'Failed to send broadcast. Error: {str(err)}')

    return result


def get_broadcast_document(data: dict, sent_by: str, filters: dict):
    # Mongo does not support `DateField` so we convert it to `DateTimeField`
    date_joined = None
    if filters.get('date_joined'):
        date_joined = {
            'after': datetime.combine(filters.get('date_joined').get('after'), datetime.min.time()),
            'before': datetime.combine(filters.get('date_joined').get('before'), datetime.min.time()),
        }

    doc = {
        'title': data.get('title'),
        'message': data.get('message'),
        'action': data.get('action'),
        'sent_by': sent_by,
        'sent_at': datetime.utcnow(),
        'filters': {
            'platform': filters.get('platform', None),
            'date_joined': date_joined,
            'has_subscription': filters.get('has_subscription', None),
            'has_app': filters.get('has_app', None),
        },
    }

    return doc


def save_broadcast(document: dict):
    try:
        col = action_to_collection_mapping[document.get('action')]
        conn = mongo.get_collection(db=secrets.MONGO_DB_03, col=col)
        conn.insert_one(document)
    except Exception as err:
        logger.error(f'Failed to save broadcast. Error: {str(err)}')
