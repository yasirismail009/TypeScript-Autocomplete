from rest_framework.decorators import api_view, permission_classes, authentication_classes
from utils.logger import logger
from api.broadcast.services import send_broadcast, save_broadcast, get_broadcast_document
from utils.responses import ok, bad_request, internal_server_error
from api.broadcast.serializers import NewsBroadcastSerializer
from api.broadcast.serializers import AnnouncementBroadcastSerializer
from api.broadcast.serializers import FalsePositiveHostBroadcastSerializer
from api.broadcast.serializers import FalsePositiveAppBroadcastSerializer
from api.broadcast.serializers import AnnouncementExternalLinkBroadcastSerializer
from datetime import datetime
from bson.json_util import dumps
import traceback


@api_view(['POST'])
def send_news(request):
    try:
        serializer = NewsBroadcastSerializer(data=request.data)
        if not serializer.is_valid():
            return bad_request(data=serializer.errors)

        validated_data = serializer.validated_data

        filters = dict(validated_data["users_filter"])

        del validated_data["users_filter"]
        result = send_broadcast(data=validated_data, filters=filters)

        doc = get_broadcast_document(data=validated_data, sent_by=request.user.email, filters=filters)
        doc['success_count'] = result['success_count']
        doc['failure_count'] = result['failure_count']
        doc['total_count'] = result['total_count']
        save_broadcast(document=doc)

        success_count = doc.get('success_count')
        total_count = doc.get('total_count')
        message = f"Successfully sent to {success_count}/{total_count} users"
        return ok(data=result, message=message)

    except Exception as err:
        logger.error(f'Failed to send broadcast. Error: {str(err)}')
        return internal_server_error(message=f'Failed to send broadcast')


@api_view(['POST'])
def send_announcement(request):
    try:
        serializer = AnnouncementBroadcastSerializer(data=request.data)
        if not serializer.is_valid():
            return bad_request(data=serializer.errors)

        validated_data = serializer.validated_data
        filters = dict(validated_data["users_filter"])

        del validated_data["users_filter"]
        result = send_broadcast(data=validated_data, filters=filters)

        doc = get_broadcast_document(data=validated_data, sent_by=request.user.email, filters=filters)
        doc['success_count'] = result['success_count']
        doc['failure_count'] = result['failure_count']
        doc['total_count'] = result['total_count']
        save_broadcast(document=doc)

        success_count = result.get('success_count')
        total_count = result.get('total_count')
        message = f"Successfully sent to {success_count}/{total_count} users"
        return ok(data=result, message=message)

    except Exception as err:
        logger.error(f'Failed to send broadcast. Error: {str(err)}')
        return internal_server_error(message=f'Failed to send broadcast')


@api_view(['POST'])
def send_false_positive_host(request):
    try:
        serializer = FalsePositiveHostBroadcastSerializer(data=request.data)
        if not serializer.is_valid():
            return bad_request(data=serializer.errors)

        validated_data = serializer.validated_data
        validated_data['false_positive_list'] = dumps(validated_data['false_positive_list'])
        host_type = validated_data['host_type']
        del validated_data['host_type']
        filters = dict(validated_data["users_filter"])

        del validated_data["users_filter"]

        result = send_broadcast(data=validated_data, filters=filters)
        doc = get_broadcast_document(data=validated_data, sent_by=request.user.email, filters=filters)
        doc['success_count'] = result['success_count']
        doc['failure_count'] = result['failure_count']
        doc['total_count'] = result['total_count']
        doc['host_type'] = host_type
        doc['false_positive_list'] = validated_data['false_positive_list']
        save_broadcast(document=doc)

        success_count = result.get('success_count')
        total_count = result.get('total_count')
        message = f"Successfully sent to {success_count}/{total_count} users"
        return ok(data=result, message=message)

    except Exception as err:
        logger.error(f'Failed to send broadcast. Error: {str(err)}')
        return internal_server_error(message=f'Failed to send broadcast')


@api_view(['POST'])
def send_false_positive_app(request):
    try:
        serializer = FalsePositiveAppBroadcastSerializer(data=request.data)
        if not serializer.is_valid():
            return bad_request(data=serializer.errors)

        validated_data = dict(serializer.validated_data)
        filters = dict(validated_data["users_filter"])

        del validated_data["users_filter"]

        result = send_broadcast(data=validated_data, filters=filters)

        doc = get_broadcast_document(data=validated_data, sent_by=request.user.email, filters=filters)
        doc['success_count'] = result['success_count']
        doc['failure_count'] = result['failure_count']
        doc['total_count'] = result['total_count']

        doc['app_name'] = validated_data['app_name']
        doc['app_package_name'] = validated_data['app_package_name']
        doc['app_version_name'] = validated_data['app_version_name']
        doc['app_version_code'] = validated_data['app_version_code']

        save_broadcast(document=doc)

        success_count = result.get('success_count')
        total_count = result.get('total_count')
        message = f"Successfully sent to {success_count}/{total_count} users"
        return ok(data=result, message=message)

    except Exception as err:
        logger.error(f'Failed to send broadcast. Error: {str(err)}')
        return internal_server_error(message=f'Failed to send broadcast')


@api_view(['POST'])
def send_announcement_external_link(request):
    try:
        serializer = AnnouncementExternalLinkBroadcastSerializer(data=request.data)
        if not serializer.is_valid():
            return bad_request(data=serializer.errors)

        validated_data = serializer.validated_data
        filters = dict(validated_data["users_filter"])

        del validated_data["users_filter"]

        result = send_broadcast(data=validated_data, filters=filters)

        doc = get_broadcast_document(data=validated_data, sent_by=request.user.email, filters=filters)
        doc['success_count'] = result['success_count']
        doc['failure_count'] = result['failure_count']
        doc['total_count'] = result['total_count']

        doc['url'] = validated_data['url']

        save_broadcast(document=doc)

        success_count = result.get('success_count')
        total_count = result.get('total_count')
        message = f"Successfully sent to {success_count}/{total_count} users"
        return ok(data=result, message=message)

    except Exception as err:
        logger.error(f'Failed to send broadcast. Error: {str(err)}')
        logger.error(traceback.format_exc())
        return internal_server_error(message=f'Failed to send broadcast')
