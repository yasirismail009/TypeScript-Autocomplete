from django.urls import path
from api.broadcast import views

urlpatterns = [
    path('send/news/', views.send_news),
    path('send/announcement/', views.send_announcement),
    path('send/false_positive_host/', views.send_false_positive_host),
    path('send/false_positive_app/', views.send_false_positive_app),
    path('send/announcement_external_link/', views.send_announcement_external_link)
]
