from django.urls import path
from api.stats import views

urlpatterns = [
    path('store-wise-distribution/', views.store_wise_distribution),
    path('device-wise-distribution/', views.device_wise_distribution),
    path('android-version-wise-distribution/', views.android_version_wise_distribution),
    path('country-wise-distribution/', views.country_wise_distribution),
    path('pda-version-wise-distribution/', views.pda_version_wise_distribution),
    path('store-date-wise-distribution/', views.store_date_wise_distribution),
    path('device-date-wise-distribution/', views.device_date_wise_distribution),
    path('version-date-wise-distribution/', views.version_date_wise_distribution),
    path('country-date-wise-distribution/', views.country_date_wise_distribution),
    path('pda-version-date-wise-distribution/', views.pda_version_date_wise_distribution),
]
