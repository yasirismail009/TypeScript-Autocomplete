import traceback

from rest_framework.decorators import api_view, authentication_classes, permission_classes
from utils.responses import ok, internal_server_error

from api.stats import services
@api_view(['GET'])
def store_wise_distribution(request):
    try:
        distribution = services.get_store_wise_distribution()

        data = distribution

        return ok(data=data)

    except Exception:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to store wise distribution')


@api_view(['GET'])
def device_wise_distribution(request):
    try:
        distribution = services.get_device_wise_distribution()

        data = distribution

        return ok(data=data)

    except Exception:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to device wise distribution')


@api_view(['GET'])
def android_version_wise_distribution(request):
    try:
        distribution = services.get_android_version_wise_distribution()

        data = distribution

        return ok(data=data)

    except Exception:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to android wise distribution')


@api_view(['GET'])
def country_wise_distribution(request):
    try:
        distribution = services.get_country_wise_distribution()

        data = distribution

        return ok(data=data)

    except Exception:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to country wise distribution')


@api_view(['GET'])
def pda_version_wise_distribution(request):
    try:
        distribution = services.get_pda_version_wise_distribution()

        data = distribution

        return ok(data=data)

    except Exception:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to pda version wise distribution')


@api_view(['GET'])
def store_date_wise_distribution(request):
    try:
        distribution = services.get_store_date_wise_distribution()

        data = distribution

        return ok(data=data)

    except Exception:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to pda version wise distribution')


@api_view(['GET'])
def device_date_wise_distribution(request):
    try:
        distribution = services.get_device_date_wise_distribution()

        data = distribution

        return ok(data=data)

    except Exception:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to pda version wise distribution')


@api_view(['GET'])
def version_date_wise_distribution(request):
    try:
        distribution = services.get_version_date_wise_distribution()

        data = distribution

        return ok(data=data)

    except Exception:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to pda version wise distribution')


@api_view(['GET'])
def country_date_wise_distribution(request):
    try:
        distribution = services.get_country_date_wise_distribution()

        data = distribution

        return ok(data=data)

    except Exception:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to pda version wise distribution')


@api_view(['GET'])
def pda_version_date_wise_distribution(request):
    try:
        distribution = services.get_pda_version_date_wise_distribution()

        data = distribution

        return ok(data=data)

    except Exception:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to pda version wise distribution')
