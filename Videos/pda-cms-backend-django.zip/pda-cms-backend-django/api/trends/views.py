from math import ceil
from datetime import datetime, timedelta

from rest_framework.decorators import api_view

from api.trends import services
from utils.logger import logger
from utils.responses import ok, internal_server_error, not_found


@api_view(['GET'])
def service_status(request, service):
    try:
        if service not in ['nginx']:
            return not_found()

        incidents = services.get_services_status_history(service)

        yesterday = datetime.now().replace(hour=23, minute=59, second=59, microsecond=0) - timedelta(days=1)

        labels = reversed([(yesterday - timedelta(days=i)).isoformat().split('T')[0] for i in range(0, 30)])

        data = {
            'labels': labels,
            'datasets': [
                {
                    'data': [1] * 30,
                    'barPercentage': 1,
                    'borderColor': '#262526',
                    'borderSkipped': False,
                    'borderWidth': 6,
                    'categoryPercentage': 1,
                    'label': 1,
                    'backgroundColor': ['#4FD084'] * 30,
                },
                {
                    'data': [1] * 30,
                    'barPercentage': 1,
                    'borderColor': '#262526',
                    'borderSkipped': False,
                    'borderWidth': 6,
                    'categoryPercentage': 1,
                    'label': 2,
                    'backgroundColor': ['#4FD084'] * 30,
                },
                {
                    'data': [1] * 30,
                    'barPercentage': 1,
                    'borderColor': '#262526',
                    'borderSkipped': False,
                    'borderWidth': 6,
                    'categoryPercentage': 1,
                    'label': 3,
                    'backgroundColor': ['#4FD084'] * 30,
                },
                {
                    'data': [1] * 30,
                    'barPercentage': 1,
                    'borderColor': '#262526',
                    'borderSkipped': False,
                    'borderWidth': 6,
                    'categoryPercentage': 1,
                    'label': 4,
                    'backgroundColor': ['#4FD084'] * 30,
                },
                {
                    'data': [1] * 30,
                    'barPercentage': 1,
                    'borderColor': '#262526',
                    'borderSkipped': False,
                    'borderWidth': 6,
                    'categoryPercentage': 1,
                    'label': 5,
                    'backgroundColor': ['#4FD084'] * 30,
                },
                {
                    'data': [1] * 30,
                    'barPercentage': 1,
                    'borderColor': '#262526',
                    'borderSkipped': False,
                    'borderWidth': 6,
                    'categoryPercentage': 1,
                    'label': 6,
                    'backgroundColor': ['#4FD084'] * 30,
                },
            ]
        }

        parts_in_a_day = 6
        seconds_in_one_day = 86400
        seconds_in_one_part = int(seconds_in_one_day / parts_in_a_day)

        for incident in incidents:
            unix_timestamp = incident.get('unix_timestamp')

            seconds_ago = int(yesterday.timestamp()) - unix_timestamp
            parts_ago = ceil(seconds_ago / seconds_in_one_part)
            days_ago = int(parts_ago / parts_in_a_day)
            relative_parts_ago = int(parts_ago - (days_ago * parts_in_a_day))

            data.get('datasets')[relative_parts_ago].get('backgroundColor')[-(days_ago + 1)] = '#E74C3C'

            print(parts_ago, days_ago, relative_parts_ago)

        return ok(data=data)

    except Exception as err:
        logger.error(f'Error: {str(err)}')
        return internal_server_error()
