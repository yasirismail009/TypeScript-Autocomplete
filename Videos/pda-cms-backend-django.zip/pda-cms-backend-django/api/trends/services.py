from datetime import timedelta, datetime

from utils import postgres
from core import secrets

def get_services_status_history(service):
    yesterday = datetime.now().replace(hour=23, minute=59, second=59, microsecond=0) - timedelta(days=1)

    conn = postgres.Connection(
        host=secrets.PSQL_HOST_02,
        port=secrets.PSQL_PORT_02,
        user=secrets.PSQL_USER_02,
        password=secrets.PSQL_PSWD_02,
        db=secrets.PSQL_DB_02,
    )

    rows = conn.fetch_all(
        f'SELECT status_code, status, unix_timestamp, duration_in_seconds FROM public.{service} WHERE unix_timestamp < {int(yesterday.timestamp())} AND status_code != 0 ORDER BY unix_timestamp DESC;')

    incidents = []
    for row in rows:
        status_code, status, unix_timestamp, duration_in_seconds = row

        incidents.append({
            'status_code': status_code,
            'status': status,
            'unix_timestamp': unix_timestamp,
            'duration_in_seconds': duration_in_seconds,
        })

    return incidents
