from django.urls import path
from api.trends import views

urlpatterns = [
    path('service-status/<str:service>', views.service_status),
]
