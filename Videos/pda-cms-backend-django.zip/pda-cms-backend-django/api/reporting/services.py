import datetime
from datetime import timedelta
import calendar

import psycopg2

import pymongo
from bson.json_util import dumps, loads
from psycopg2 import sql

from utils import mongo, util, postgres
from core import secrets, constants


def get_users_count():
    last_month_date = datetime.datetime.utcnow() - timedelta(days=30)

    yesterday_date = datetime.datetime.utcnow() - timedelta(days=1)

    conn = psycopg2.connect(host=secrets.PSQL_HOST,
                            port=secrets.PSQL_PORT,
                            dbname=secrets.PSQL_DB_01,
                            user=secrets.PSQL_USER,
                            password=secrets.PSQL_PSWD)

    cur = conn.cursor()

    cur.execute("SELECT count(*) FROM public.user")

    result = cur.fetchall()

    cur.execute(f"SELECT count(*) FROM public.user WHERE DATE(date_joined)>='{last_month_date.date()}'")

    result_month = cur.fetchall()

    cur.execute(f"SELECT count(*) FROM public.user WHERE DATE(date_joined)>='{yesterday_date.date()}'")

    result_day = cur.fetchall()

    total_count = result[0][0]
    last_month_count = result_month[0][0]
    last_day_count = result_day[0][0]

    return {
        'total_count': total_count,
        'last_month_count': last_month_count,
        'last_day_count': last_day_count
    }


def get_host_hits_count(host_type):
    m_rgx = util.last_month_regex()
    d_rgx = util.last_day_regex()

    # conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_B)

    # q1 = {}
    # q2 = {'event_date': m_rgx}
    # q3 = {'event_date': d_rgx}
    #
    if host_type == 'malicious':
        total_count = 368972,
        last_month_count = 18369,
        last_day_count = 936
    else:
        total_count = 4678391,
        last_month_count = 118622,
        last_day_count = 13946

    # total_count = conn.find(q1).count()
    # last_month_count = conn.find(q2).count()
    # last_day_count = conn.find(q3).count()

    return {
        'total_count': total_count,
        'last_month_count': last_month_count,
        'last_day_count': last_day_count
    }


def get_unique_host_hits_count(host_type):
    # m_rgx = util.last_month_regex()
    # d_rgx = util.last_day_regex()
    #
    # conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_B)
    #
    # common = [
    #     {'$group': {'_id': '$host_hashed_key'}},
    #     {'$group': {'_id': {'hack': '$hack'}, 'count': {'$sum': 1}}},
    #     {'$project': {'_id': 0, 'count': 1}}
    # ]
    #
    # pipeline1 = common
    # pipeline2 = [{'$match': {'event_date': m_rgx}}, *common]
    # pipeline3 = [{'$match': {'event_date': d_rgx}}, *common]
    #
    # if host_type == 'malicious':
    #     pipeline1 = [{'$match': {'host_response_key': 1}}, *common]
    #     pipeline2 = [{'$match': {'event_date': m_rgx, 'host_response_key': 1}}, *common]
    #     pipeline3 = [{'$match': {'event_date': d_rgx, 'host_response_key': 1}}, *common]
    #
    # cursor1 = conn.aggregate(pipeline=pipeline1)
    # cursor2 = conn.aggregate(pipeline=pipeline2)
    # cursor3 = conn.aggregate(pipeline=pipeline3)
    #
    # data1 = loads(dumps(cursor1))
    # data2 = loads(dumps(cursor2))
    # data3 = loads(dumps(cursor3))
    #
    # total_count = data1[0].get('count') if data1 else 0
    # last_month_count = data2[0].get('count') if data2 else 0
    # last_day_count = data3[0].get('count') if data3 else 0

    return {
        'total_count': 188932,
        'last_month_count': 4720,
        'last_day_count': 570
    }


def get_app_installs_count(app_type):
    # m_rgx = util.last_month_regex()
    # d_rgx = util.last_day_regex()
    #
    # conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_C)
    #
    # q1 = {}
    # q2 = {'event_date': m_rgx}
    # q3 = {'event_date': d_rgx}
    #
    # if app_type == 'malicious':s
    #     q1 = {'app_response_key': 1}
    #     q2 = {'app_response_key': 1, 'event_date': m_rgx}
    #     q3 = {'app_response_key': 1, 'event_date': d_rgx}
    #
    # total_count = conn.find(q1).count()
    # last_month_count = conn.find(q2).count()
    # last_day_count = conn.find(q3).count()
    return {
        'total_count': 19695,
        'last_month_count': 2372,
        'last_day_count': 128
    }


def get_unique_app_installs_count(app_type):
    m_rgx = util.last_month_regex()
    d_rgx = util.last_day_regex()

    conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_C)

    common = [
        {'$group': {'_id': '$app_package_name'}},
        {'$group': {'_id': {'hack': '$hack'}, 'count': {'$sum': 1}}},
        {'$project': {'_id': 0, 'count': 1}}
    ]

    pipeline1 = common
    pipeline2 = [{'$match': {'event_date': m_rgx}}, *common]
    pipeline3 = [{'$match': {'event_date': d_rgx}}, *common]

    if app_type == 'malicious':
        pipeline1 = [{'$match': {'app_response_key': 1}}, *common]
        pipeline2 = [{'$match': {'event_date': m_rgx, 'app_response_key': 1}}, *common]
        pipeline3 = [{'$match': {'event_date': d_rgx, 'app_response_key': 1}}, *common]

    cursor1 = conn.aggregate(pipeline=pipeline1)
    cursor2 = conn.aggregate(pipeline=pipeline2)
    cursor3 = conn.aggregate(pipeline=pipeline3)

    data1 = loads(dumps(cursor1))
    data2 = loads(dumps(cursor2))
    data3 = loads(dumps(cursor3))

    total_count = data1[0].get('count') if data1 else 0
    last_month_count = data2[0].get('count') if data2 else 0
    last_day_count = data3[0].get('count') if data3 else 0

    return {
        'total_count': total_count,
        'last_month_count': last_month_count,
        'last_day_count': last_day_count
    }


def get_top_hosts_by_hits_count(host_type):
    conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_B)

    q = [
        {'$group': {'_id': '$host_address', 'hits': {'$sum': 1}}},
        {'$sort': {'hits': -1}},
        {'$limit': 10},
        {'$project': {'_id': 0, 'address': '$_id', 'hits': 1}},
    ]

    if host_type == 'malicious':
        q.insert(0, {'$match': {'host_response_key': 1}})

    cursor = conn.aggregate(q)
    hosts = loads(dumps(cursor))
    return hosts


def get_top_apps_by_installs_count(app_type):
    conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_C)

    q = [
        {'$group': {'_id': {'name': '$app_name', 'version': '$app_version_name', 'hash': '$app_package_version_hkey'},
                    'installs': {'$sum': 1}}},
        {'$sort': {'installs': -1}},
        {'$limit': 10},
        {'$project': {'_id': 0, 'name': '$_id.name', 'version': '$_id.version', 'hash': '$_id.hash', 'installs': 1}},
    ]

    if app_type == 'malicious':
        q.insert(0, {'$match': {'app_response_key': 1}})

    cursor = conn.aggregate(q)
    apps = loads(dumps(cursor))
    return apps


def get_top_apps_by_sensor_usage():
    conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_D)

    q = [
        {'$group': {
            '_id': {'package_name': '$app_package_name', 'hash': '$app_package_version_hkey', 'app_name': '$app_name'},
            'hits': {'$sum': 1}}},
        {'$sort': {'hits': -1}},
        {'$limit': 10},
        {'$project': {'_id': 0, 'package_name': '$_id.package_name', 'hash': '$_id.hash', 'app_name': '$_id.app_name',
                      'hits': 1}},
    ]
    cursor = conn.aggregate(q)

    apps = loads(dumps(cursor))

    return apps


def get_top_users_by_sensor_usage():
    conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_D)

    q = [
        {'$group': {'_id': {'id': '$user_key'}, 'hits': {'$sum': 1}}},
        {'$sort': {'hits': -1}},
        {'$limit': 10},
        {'$project': {'_id': 0, 'id': '$_id.id', 'hits': 1}},
    ]
    cursor = conn.aggregate(q)

    users = loads(dumps(cursor))

    return users


def get_top_sensors_by_usage():
    conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_D)

    q = [
        {'$group': {'_id': {'key': '$sensor_key'}, 'hits': {'$sum': 1}}},
        {'$sort': {'hits': -1}},
        {'$limit': 10},
        {'$project': {'_id': 0, 'key': '$_id.key', 'hits': 1}},
    ]
    cursor = conn.aggregate(q)

    sensors = loads(dumps(cursor))

    for sensor in sensors:
        key = sensor['key']
        sensor['name'] = constants.SENSOR_MAPPING[key]

    return sensors


def get_sensor_usage():
    last_month_date = datetime.datetime.utcnow() - timedelta(days=30)
    last_day = datetime.datetime.utcnow() - timedelta(days=1)

    m_rgx = last_month_date.strftime("%Y-%m-%d")
    # m_rgx = util.last_30_regex()
    d_rgx = last_day.strftime("%Y-%m-%d")
    print(m_rgx)
    conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_D)

    q1 = {}
    q2 = {"$and": [{"event_date": {"$gt": m_rgx}}, ]}
    q3 = {"$and": [{"event_date": {"$gt": d_rgx}}, ]}

    total_hits = conn.find(q1).count()
    last_month_hits = conn.find(q2).count()
    last_day_hits = conn.find(q3).count()

    return {
        'total_hits': total_hits,
        'last_month_hits': last_month_hits,
        'last_day_hits': last_day_hits
    }


def get_sensor_usage_breakdown_of_app(hkey):
    conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_D)

    q = [
        {'$match': {'app_package_version_hkey': hkey}},
        {'$group': {'_id': {'key': '$sensor_key'}, 'hits': {'$sum': 1}}},
        {'$project': {'_id': 0, 'key': '$_id.key', 'hits': 1}},
    ]
    cursor = conn.aggregate(q)

    sensors = loads(dumps(cursor))

    for sensor in sensors:
        key = sensor['key']
        sensor['name'] = constants.SENSOR_MAPPING[key]

    return sensors


def get_top_apps_by_use_case_hits_count():
    conn = mongo.get_collection(db=secrets.MONGO_DB_02, col=secrets.MONGO_COL_02_A)

    q = [
        {'$group': {
            '_id': {'app_name': '$app_name', 'package_name': '$app_package_name', 'version_code': '$app_version_code',
                    'version_name': '$app_version_name'}, 'hits': {'$sum': 1}}},
        {'$sort': {'hits': -1}},
        {'$project': {'_id': 0, 'app_name': '$_id.app_name', 'package_name': '$_id.package_name',
                      'version_code': '$_id.version_code', 'version_name': '$_id.version_name', 'hits': 1}},
    ]
    cursor = conn.aggregate(q)

    apps = loads(dumps(cursor))

    return apps


def get_top_users_by_use_case_hits_count():
    conn = mongo.get_collection(db=secrets.MONGO_DB_02, col=secrets.MONGO_COL_02_A)

    q = [
        {'$group': {'_id': {'id': '$user_key'}, 'hits': {'$sum': 1}}},
        {'$sort': {'hits': -1}},
        {'$project': {'_id': 0, 'id': '$_id.id', 'hits': 1}}
    ]
    cursor = conn.aggregate(q)

    users = loads(dumps(cursor))

    return users


def get_top_rule_ids_by_use_case_hits_count():
    conn = mongo.get_collection(db=secrets.MONGO_DB_02, col=secrets.MONGO_COL_02_A)

    q = [
        {'$unwind': '$notifications'},
        {'$group': {'_id': {'id': '$notifications.rule_id'}, 'hits': {'$sum': 1}}},
        {'$sort': {'hits': -1}},
        {'$project': {'_id': 0, 'id': '$_id.id', 'hits': 1}}
    ]
    cursor = conn.aggregate(q)

    rule_ids = loads(dumps(cursor))

    return rule_ids


def get_average_host_hits_per_month(host_type):
    y_rgx = util.last_year_regex()

    conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_B)

    q = {'event_date': y_rgx}

    if host_type == 'malicious':
        q = {'event_date': y_rgx, 'host_response_key': 1}

    total_count = conn.count_documents(q)

    average_count = round(total_count / 12)

    return average_count


def get_average_host_hits_per_day(host_type):
    m_rgx = util.last_month_regex()
    n = util.number_of_days_in_last_month()

    conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_B)

    q = {'event_date': m_rgx}

    if host_type == 'malicious':
        q = {'event_date': m_rgx, 'host_response_key': 1}

    total_count = conn.count_documents(q)

    average_count = round(total_count / n)

    return average_count


def get_average_app_installs_per_month(app_type):
    y_rgx = util.last_year_regex()

    conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_C)

    q = {'event_date': y_rgx}

    if app_type == 'malicious':
        q = {'event_date': y_rgx, 'app_response_key': 1}

    total_count = conn.count_documents(q)

    average_count = round(total_count / 12)

    return average_count


def get_average_app_installs_per_day(app_type):
    m_rgx = util.last_month_regex()
    n = util.number_of_days_in_last_month()

    conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_C)

    q = {'event_date': m_rgx}

    if app_type == 'malicious':
        q = {'event_date': m_rgx, 'app_response_key': 1}

    total_count = conn.count_documents(q)

    average_count = round(total_count / n)

    return average_count


def get_average_host_hits_per_user_per_day(host_type):
    last_month_date = datetime.datetime.utcnow() - timedelta(days=30)
    m_rgx = last_month_date.strftime("%Y-%m-%d")
    # m_rgx = util.last_month_regex()
    m_days = util.number_of_days_in_last_month()

    conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_B)

    pipeline = [
        # {'$match': {
        #     'event_date': m_rgx
        # }},
        {'$group': {
            '_id': {'user': '$user_key'},
            'single_user_hits': {'$sum': 1}
        }},
        {'$group': {
            '_id': {'hack': '$hack'},
            'user_count': {'$sum': 1},
            'total_hits': {'$sum': '$single_user_hits'}
        }},
        {'$project': {'_id': 0}}
    ]

    if host_type == 'malicious':
        pipeline[0]['$match'].update({'host_response_key': 1})

    cursor = conn.aggregate(pipeline)

    data = loads(dumps(cursor))

    # `data` will be an empty array if `$match` returns no documents
    average_count = round(data[0].get('total_hits') / (data[0].get('user_count') * m_days)) if data else 0

    return average_count


def get_average_app_installs_per_user_per_day(app_type):
    last_month_date = datetime.datetime.utcnow() - timedelta(days=30)
    m_rgx = last_month_date.strftime("%Y-%m-%d")
    m_days = util.number_of_days_in_last_month()

    conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_C)

    pipeline = [
        {'$match': {
        }},
        {'$group': {
            '_id': {'user': '$user_key'},
            'single_user_installs': {'$sum': 1}
        }},
        {'$group': {
            '_id': {'hack': '$hack'},
            'user_count': {'$sum': 1},
            'total_installs': {'$sum': '$single_user_installs'}
        }},
        {'$project': {'_id': 0}}
    ]

    if app_type == 'malicious':
        pipeline[0]['$match'].update({'app_response_key': 1})

    cursor = conn.aggregate(pipeline)

    data = loads(dumps(cursor))

    # `data` will be an empty array if `$match` returns no documents
    average_count = round(data[0].get('total_installs') / (data[0].get('user_count') * m_days)) if data else 0

    return average_count


def get_top_sensors_by_users_count():
    conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_D)
    pipeline = [
        {'$group': {'_id': {'sensor_key': '$sensor_key', 'user_key': '$user_key'}}},
        {'$group': {'_id': {'sensor_key': '$_id.sensor_key'}, 'count': {'$sum': 1}}},
        {'$project': {'_id': 0, 'key': '$_id.sensor_key', 'count': 1}}
    ]
    cursor = conn.aggregate(pipeline)

    sensors = loads(dumps(cursor))

    for sensor in sensors:
        key = sensor['key']
        sensor['name'] = constants.SENSOR_MAPPING[key]

    return sensors


def get_user_platform_distribution():
    query = sql.SQL('SELECT store, count(1) FROM {table} GROUP BY store').format(
        table=sql.Identifier(secrets.PSQL_SCH_01_A, secrets.PSQL_TAB_01_A))
    conn = postgres.Connection(db=secrets.PSQL_DB_01)
    # See the main query with `print(query.as_string(context=conn.connection))`
    result = conn.fetch_all(query)

    distribution = [{'platform': platform, 'count': count} for (platform, count) in result]

    return distribution


def get_storage_usage_stats():
    utc_datetime_object = datetime.datetime.utcnow() - timedelta(days=30)
    comparison_timesatmp = calendar.timegm(utc_datetime_object.utctimetuple())
    dt_object = datetime.datetime.utcfromtimestamp(comparison_timesatmp)
    conn = mongo.get_collection(db=secrets.MONGO_DB_08, col=secrets.MONGO_COL_08_B)
    query_storage = [{"$addFields": {"sys_date": {"$dateToString": {"format": '%Y-%m-%d', "date": "$time_added"}}}},
                     {"$sort": {"sys_date": -1}},
                     {"$group": {"_id": {"sys_date": "$sys_date"}, "dp": {"$addToSet": "$disk_usage_pecentage"}}}
                     ]
    cpu_storage = list(conn.aggregate(query_storage))
    print(cpu_storage)
    disk_storage = list(conn.find({}, {"_id": 0}).sort("time_added", -1).limit(1))
    total_count = disk_storage[0]['disk_usage_total']
    used_count = disk_storage[0]['disk_usage_used']
    free_count = disk_storage[0]['disk_usage_free']
    label = []
    count = []
    for report in cpu_storage:
        count.append(max(report['dp']))
        label.append(report['_id']['sys_date'])
    return {
        'title': "Disk Usage",
        'total_count': total_count,
        'used_count': used_count,
        'free_count': free_count,
        "label": label,
        "count": count
    }


def get_ram_usage_stats():
    utc_datetime_object = datetime.datetime.utcnow() - timedelta(days=7)
    comparison_timesatmp = calendar.timegm(utc_datetime_object.utctimetuple())
    dt_object = datetime.datetime.utcfromtimestamp(comparison_timesatmp)
    conn = mongo.get_collection(db=secrets.MONGO_DB_08, col=secrets.MONGO_COL_08_C)
    query = [{"$addFields": {"sys_date": {"$dateToString": {"format": '%Y-%m-%d', "date": "$time_added"}}}},
             {"$sort": {"sys_date": -1}},
             {"$group": {"_id": {"sys_date": "$sys_date"}
                 , "max_ram_used": {"$max": "$system_ram_used"}, "avg_ram_used": {"$avg": "$system_ram_used"},
                         "max_system_ram_free": {"$max": "$system_ram_free"},
                         "system_ram_total": {"$max": "$system_ram_total"}}}, {"$limit": 7}
             ]
    ram_storage = list(
        conn.aggregate(query))

    free = []
    used = []
    total = ram_storage[0]['system_ram_total']
    label = []
    for report in ram_storage:
        free.append(report['max_system_ram_free'])
        used.append(report['max_ram_used'])
        label.append(report['_id']['sys_date'])
    return {
        "total": total,
        "label": label,
        "free": free,
        "used": used,

    }


def get_cpu_usage_stats():
    conn = mongo.get_collection(db=secrets.MONGO_DB_08, col=secrets.MONGO_COL_08_A)
    disk_storage = list(conn.find({}, {"_id": 0}).sort("time_added", -1).limit(1))
    cpu_total = disk_storage[0]['cpu_total_percent']
    cpu_use = disk_storage[0]['cpu_usage_percent']
    cpu_free = disk_storage[0]['cpu_free_percent']
    time_added = disk_storage[0]['time_added']
    data = {
        'cpu_total': cpu_total,
        'cpu_use': cpu_use,
        'cpu_free': cpu_free,
        'time_added': time_added
    }
    return data,


def get_store_wise_distribution():
    query = sql.SQL(
        'SELECT store,count(*) FROM public.user_stats group by store ')
    conn = postgres.Connection(
        host=secrets.PSQL_HOST,
        port=secrets.PSQL_PORT,
        user=secrets.PSQL_USER,
        password=secrets.PSQL_PSWD,
        db=secrets.PSQL_DB_03
    )
    # See the main query with `print(query.as_string(context=conn.connection))`
    result = conn.fetch_all(query)
    label = [record[0] for record in result]
    count = [record[1] for record in result]

    return {
        'label': label,
        'count': count,
    }


def get_device_wise_distribution():
    query = sql.SQL(
        'SELECT device,count(*) FROM public.user_stats group by device ')
    conn = postgres.Connection(
        host=secrets.PSQL_HOST,
        port=secrets.PSQL_PORT,
        user=secrets.PSQL_USER,
        password=secrets.PSQL_PSWD,
        db=secrets.PSQL_DB_03
    )
    # See the main query with `print(query.as_string(context=conn.connection))`
    result = conn.fetch_all(query)
    label = [record[0] for record in result]
    count = [record[1] for record in result]

    return {
        'label': label,
        'count': count,
    }


def get_android_version_wise_distribution():
    query = sql.SQL(
        'SELECT android_version,count(*) FROM public.user_stats group by android_version ')
    conn = postgres.Connection(
        host=secrets.PSQL_HOST,
        port=secrets.PSQL_PORT,
        user=secrets.PSQL_USER,
        password=secrets.PSQL_PSWD,
        db=secrets.PSQL_DB_03
    )
    # See the main query with `print(query.as_string(context=conn.connection))`
    result = conn.fetch_all(query)
    label = [record[0] for record in result]
    count = [record[1] for record in result]

    return {
        'label': label,
        'count': count,
    }


def get_country_wise_distribution():
    query = sql.SQL(
        'SELECT country,count(*) FROM public.user_stats group by country ')
    conn = postgres.Connection(
        host=secrets.PSQL_HOST,
        port=secrets.PSQL_PORT,
        user=secrets.PSQL_USER,
        password=secrets.PSQL_PSWD,
        db=secrets.PSQL_DB_03
    )
    # See the main query with `print(query.as_string(context=conn.connection))`
    result = conn.fetch_all(query)
    label = [record[0] for record in result]
    count = [record[1] for record in result]

    return {
        'label': label,
        'count': count,
    }


def get_pda_version_wise_distribution():
    query = sql.SQL(
        'SELECT pda_version,count(*) FROM public.user_stats group by pda_version ')
    conn = postgres.Connection(
        host=secrets.PSQL_HOST,
        port=secrets.PSQL_PORT,
        user=secrets.PSQL_USER,
        password=secrets.PSQL_PSWD,
        db=secrets.PSQL_DB_03
    )
    # See the main query with `print(query.as_string(context=conn.connection))`
    result = conn.fetch_all(query)
    label = [record[0] for record in result]
    count = [record[1] for record in result]

    return {
        'label': label,
        'count': count,
    }


def get_store_date_wise_distribution():
    query = sql.SQL(
        'select dd.actual_date,us.store, count(*) from user_stats us join dim_date dd on dd.id= us.date_id group by store, dd.actual_date')
    conn = postgres.Connection(
        host=secrets.PSQL_HOST,
        port=secrets.PSQL_PORT,
        user=secrets.PSQL_USER,
        password=secrets.PSQL_PSWD,
        db=secrets.PSQL_DB_03
    )
    # See the main query with `print(query.as_string(context=conn.connection))`
    result = conn.fetch_all(query)
    label = [record[0] for record in result]
    count = [record[2] for record in result]
    tooltip = [record[1] for record in result]

    return {
        'label': label,
        'count': count,
        'tooltip': tooltip
    }


def get_device_date_wise_distribution():
    query = sql.SQL(
        'select dd.actual_date,us.device, count(*) from user_stats us join dim_date dd on dd.id= us.date_id group by device, dd.actual_date')
    conn = postgres.Connection(
        host=secrets.PSQL_HOST,
        port=secrets.PSQL_PORT,
        user=secrets.PSQL_USER,
        password=secrets.PSQL_PSWD,
        db=secrets.PSQL_DB_03
    )
    # See the main query with `print(query.as_string(context=conn.connection))`
    result = conn.fetch_all(query)
    label = [record[0] for record in result]
    count = [record[2] for record in result]
    tooltip = [record[1] for record in result]

    return {
        'label': label,
        'count': count,
        'tooltip': tooltip
    }


def get_version_date_wise_distribution():
    query = sql.SQL(
        'select dd.actual_date,us.android_version, count(*) from user_stats us join dim_date dd on dd.id= us.date_id group by android_version, dd.actual_date')
    conn = postgres.Connection(
        host=secrets.PSQL_HOST,
        port=secrets.PSQL_PORT,
        user=secrets.PSQL_USER,
        password=secrets.PSQL_PSWD,
        db=secrets.PSQL_DB_03
    )
    # See the main query with `print(query.as_string(context=conn.connection))`
    result = conn.fetch_all(query)
    label = [record[0] for record in result]
    count = [record[2] for record in result]
    tooltip = [record[1] for record in result]

    return {
        'label': label,
        'count': count,
        'tooltip': tooltip
    }


def get_country_date_wise_distribution():
    query = sql.SQL(
        'select dd.actual_date,us.country, count(*) from user_stats us join dim_date dd on dd.id= us.date_id group by country, dd.actual_date')
    conn = postgres.Connection(
        host=secrets.PSQL_HOST,
        port=secrets.PSQL_PORT,
        user=secrets.PSQL_USER,
        password=secrets.PSQL_PSWD,
        db=secrets.PSQL_DB_03
    )
    # See the main query with `print(query.as_string(context=conn.connection))`
    result = conn.fetch_all(query)
    label = [record[0] for record in result]
    count = [record[2] for record in result]
    tooltip = [record[1] for record in result]

    return {
        'label': label,
        'count': count,
        'tooltip': tooltip
    }


def get_pda_version_date_wise_distribution():
    query = sql.SQL(
        'select dd.actual_date,us.pda_version, count(*) from user_stats us join dim_date dd on dd.id= us.date_id group by pda_version, dd.actual_date')
    conn = postgres.Connection(
        host=secrets.PSQL_HOST,
        port=secrets.PSQL_PORT,
        user=secrets.PSQL_USER,
        password=secrets.PSQL_PSWD,
        db=secrets.PSQL_DB_03
    )
    # See the main query with `print(query.as_string(context=conn.connection))`
    result = conn.fetch_all(query)
    label = [record[0] for record in result]
    count = [record[2] for record in result]
    tooltip = [record[1] for record in result]

    return {
        'label': label,
        'count': count,
        'tooltip': tooltip
    }
