import traceback

from rest_framework.decorators import api_view, authentication_classes, permission_classes
from utils.responses import ok, internal_server_error

from api.reporting import services


@api_view(['GET'])
def users_count(request):
    try:
        data = services.get_users_count()

        return ok(data=data)

    except Exception:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to get count')


@api_view(['GET'])
def host_hits_count(request):
    try:
        host_type = request.query_params.get('type', 'all')
        is_unique = request.query_params.get('unique', 'false')

        if host_type not in ['all', 'malicious'] or is_unique not in ['true', 'false']:
            return ok()

        data = None
        if is_unique == 'false':
            data = services.get_host_hits_count(host_type)
        elif is_unique == 'true':
            data = services.get_unique_host_hits_count(host_type)

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get count')


@api_view(['GET'])
def app_installs_count(request):
    try:
        app_type = request.query_params.get('type', 'all')
        is_unique = request.query_params.get('unique', 'false')

        if app_type not in ['all', 'malicious'] or is_unique not in ['true', 'false']:
            return ok()

        data = None
        if is_unique == 'false':
            data = services.get_app_installs_count(app_type)
        elif is_unique == 'true':
            data = services.get_unique_app_installs_count(app_type)

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get count')


@api_view(['GET'])
def top_hosts_by_hits_count(request):
    try:
        host_type = request.query_params.get('type', 'all')

        if host_type not in ['all', 'malicious']:
            return ok()

        hosts = services.get_top_hosts_by_hits_count(host_type)

        data = {'hosts': hosts}
        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get hosts')


@api_view(['GET'])
def top_apps_by_installs_count(request):
    try:
        app_type = request.query_params.get('type', 'all')

        if app_type not in ['all', 'malicious']:
            return ok()

        apps = services.get_top_apps_by_installs_count(app_type)

        data = {'apps': apps}
        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get apps')


@api_view(['GET'])
def top_apps_by_sensor_usage(request):
    try:
        apps = services.get_top_apps_by_sensor_usage()

        data = {'apps': apps}

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get apps')


@api_view(['GET'])
def top_users_by_sensor_usage(request):
    try:
        users = services.get_top_users_by_sensor_usage()

        data = {'users': users}

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get users')


@api_view(['GET'])
def top_sensors_by_usage(request):
    try:
        sensors = services.get_top_sensors_by_usage()

        data = {'sensors': sensors}

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get sensors')


@api_view(['GET'])
def sensor_usage(request):
    try:
        data = services.get_sensor_usage()

        return ok(data=data)

    except Exception:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to get usage')


@api_view(['GET'])
def sensor_usage_breakdown_of_app(request, hkey):
    try:
        sensors = services.get_sensor_usage_breakdown_of_app(hkey=hkey)

        data = {'sensors': sensors}

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get breakdown')


@api_view(['GET'])
def top_apps_by_use_case_hits_count(request):
    try:
        apps = services.get_top_apps_by_use_case_hits_count()

        data = {'apps': apps}

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get apps')


@api_view(['GET'])
def top_users_by_use_case_hits_count(request):
    try:
        users = services.get_top_users_by_use_case_hits_count()

        data = {'users': users}

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get users')


@api_view(['GET'])
def top_rule_ids_by_use_case_hits_count(request):
    try:
        rule_ids = services.get_top_rule_ids_by_use_case_hits_count()

        data = {'rule_ids': rule_ids}

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get rule IDs')


@api_view(['GET'])
def average_host_hits_per_month(request):
    try:
        host_type = request.query_params.get('type', 'all')

        if host_type not in ['all', 'malicious']:
            return ok()

        average_count = services.get_average_host_hits_per_month(host_type=host_type)

        data = {'average_count': average_count}

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get average count')


@api_view(['GET'])
def average_host_hits_per_day(request):
    try:
        host_type = request.query_params.get('type', 'all')

        if host_type not in ['all', 'malicious']:
            return ok()

        average_count = services.get_average_host_hits_per_day(host_type=host_type)

        data = {'average_count': average_count}

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get average count')


@api_view(['GET'])
def average_app_installs_per_month(request):
    try:
        app_type = request.query_params.get('type', 'all')

        if app_type not in ['all', 'malicious']:
            return ok()

        average_count = services.get_average_app_installs_per_month(app_type=app_type)

        data = {'average_count': average_count}

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get average count')


@api_view(['GET'])
def average_app_installs_per_day(request):
    try:
        app_type = request.query_params.get('type', 'all')

        if app_type not in ['all', 'malicious']:
            return ok()

        average_count = services.get_average_app_installs_per_day(app_type=app_type)

        data = {'average_count': average_count}

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get average count')


@api_view(['GET'])
def average_host_hits_per_user_per_day(request):
    try:
        host_type = request.query_params.get('type', 'all')

        if host_type not in ['all', 'malicious']:
            return ok()

        average_count = services.get_average_host_hits_per_user_per_day(host_type=host_type)

        data = {'average_count': average_count}

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get average count')


@api_view(['GET'])
def average_app_installs_per_user_per_day(request):
    try:
        app_type = request.query_params.get('type', 'all')

        if app_type not in ['all', 'malicious']:
            return ok()

        average_count = services.get_average_app_installs_per_user_per_day(app_type=app_type)

        data = {'average_count': average_count}

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get average count')


@api_view(['GET'])
def top_sensors_by_users_count(request):
    try:
        sensors = services.get_top_sensors_by_users_count()

        data = {'sensors': sensors}

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get sensors')


@api_view(['GET'])
def user_platform_distribution(request):
    try:
        distribution = services.get_user_platform_distribution()

        data = {'distribution': distribution}

        return ok(data=data)

    except Exception:
        return internal_server_error(message='Failed to get distribution')


@api_view(['GET'])
def storage_usage_stats(request):
    try:
        distribution = services.get_storage_usage_stats()

        data = distribution

        return ok(data=data)

    except Exception:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to get disk usage')


@api_view(['GET'])
def ram_usage_stats(request):
    try:
        distribution = services.get_ram_usage_stats()

        data = distribution

        return ok(data=data)

    except Exception:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to get ram usage')


@api_view(['GET'])
def cpu_usage_stats(request):
    try:
        distribution = services.get_cpu_usage_stats()

        data = distribution

        return ok(data=data)

    except Exception:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to get cpu usage')


@api_view(['GET'])
def store_wise_distribution(request):
    try:
        distribution = services.get_store_wise_distribution()

        data = distribution

        return ok(data=data)

    except Exception:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to store wise distribution')


@api_view(['GET'])
def device_wise_distribution(request):
    try:
        distribution = services.get_device_wise_distribution()

        data = distribution

        return ok(data=data)

    except Exception:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to device wise distribution')


@api_view(['GET'])
def android_version_wise_distribution(request):
    try:
        distribution = services.get_android_version_wise_distribution()

        data = distribution

        return ok(data=data)

    except Exception:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to android wise distribution')


@api_view(['GET'])
def country_wise_distribution(request):
    try:
        distribution = services.get_country_wise_distribution()

        data = distribution

        return ok(data=data)

    except Exception:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to country wise distribution')


@api_view(['GET'])
def pda_version_wise_distribution(request):
    try:
        distribution = services.get_pda_version_wise_distribution()

        data = distribution

        return ok(data=data)

    except Exception:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to pda version wise distribution')


@api_view(['GET'])
def store_date_wise_distribution(request):
    try:
        distribution = services.get_store_date_wise_distribution()

        data = distribution

        return ok(data=data)

    except Exception:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to pda version wise distribution')


@api_view(['GET'])
def device_date_wise_distribution(request):
    try:
        distribution = services.get_device_date_wise_distribution()

        data = distribution

        return ok(data=data)

    except Exception:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to pda version wise distribution')


@api_view(['GET'])
def version_date_wise_distribution(request):
    try:
        distribution = services.get_version_date_wise_distribution()

        data = distribution

        return ok(data=data)

    except Exception:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to pda version wise distribution')


@api_view(['GET'])
def country_date_wise_distribution(request):
    try:
        distribution = services.get_country_date_wise_distribution()

        data = distribution

        return ok(data=data)

    except Exception:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to pda version wise distribution')


@api_view(['GET'])
def pda_version_date_wise_distribution(request):
    try:
        distribution = services.get_pda_version_date_wise_distribution()

        data = distribution

        return ok(data=data)

    except Exception:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to pda version wise distribution')
