from datetime import date
from rest_framework.serializers import ModelSerializer,Serializer, CharField, ValidationError


class PackageName(Serializer):
    package_name = CharField(required=True)
