from django.urls import path
from api.apps import views

urlpatterns = [
    path('app-stats/', views.app_stats),
    path('user-installed-app/', views.user_installed_app),
    path('app-hit-url/', views.app_hit_url),
    path('app-hit-url-malicious/<str:package_name>/', views.app_hit_url_malicious),
    path('app-os-wise/<str:package_name>', views.app_os_wise),
    path('host-stats/<str:host_address>', views.host_stats),
    path('hits-by-host/<str:host_address>', views.user_installed_host),
    path('user-hit-host/<str:host_address>/', views.user_hit_host),
    path('app-hit-host/<str:host_address>/', views.app_hit_host),
    path('app-permission-details/', views.app_permission_details),
]
