from bson.json_util import dumps, loads
from psycopg2 import sql

from core.settings import PER_PAGE
from utils import mongo, util, postgres
from core import secrets, settings
import datetime
from datetime import timedelta
import calendar


def total_app_stats(stats):
    conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_C)
    query_total_user = [{"$match": {"app_package_name": stats}},
                        {"$group": {"_id": {"user_key": "$user_key"}, "total": {"$sum": 1}}},
                        {"$group": {"_id": "number_of_user_using_app", "count": {"$sum": "$total"}}}]
    query_total_permission = [{"$match": {"app_package_name": stats}},
                              {"$group": {"_id": {"permissions": "$permissions"},
                                          }}]
    app_total_user = list(conn.aggregate(query_total_user))
    app_danger_permissions = list(conn.aggregate(query_total_permission))
    total_permissions_list = []
    for per in app_danger_permissions:
        total_permissions_list.append(per['_id']['permissions'])
    updated_list = []
    for s in total_permissions_list:
        if s != None:
            updated_list += s
        else:
            pass

    if updated_list:
        total_danger_permissions = len(updated_list)
    else:
        total_danger_permissions = 0
    if app_total_user:
        if app_total_user[0]['count']:
            total_count_user = app_total_user[0]['count']
        else:
            total_count_user = 0
    else:
        total_count_user = 0

    return {
        'user_total_count': total_count_user,
        'user_danger_permissions': total_danger_permissions,
    }


def user_installed_apps_stats(stats):
    utc_datetime_object = datetime.datetime.utcnow() - timedelta(days=30)
    comparison_timesatmp = calendar.timegm(utc_datetime_object.utctimetuple())
    # 30 days old time stamp
    dt_object = datetime.datetime.utcfromtimestamp(comparison_timesatmp)

    conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_C)

    query_last30_days_user = [
        {"$match": {"$and": [{"app_package_name": stats}]}},
        {"$group": {
            "_id": {"user_key": "$user_key"}, "e_date": {"$first": "$event_date"}}},
        {"$group": {"_id": {"event_date": "$e_date"}, "user_count": {"$sum": 1}}}]
    last30_total_app_user = list(conn.aggregate(query_last30_days_user))
    label = []
    data = []
    for tabledata in last30_total_app_user:
        data.append(tabledata['user_count'])
        label.append(tabledata['_id']['event_date'])

    # last_month_count = len(app_id_last_month)
    # last_day_count = len(app_id_last_day)

    return {
        'label': label,
        'count': data,
    }


def app_url_stats(stats, page):
    skip = (page - 1) * settings.PER_PAGE
    conn2 = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_B)

    query_url_count = [{"$match": {"app_package_name": stats}},
                       {"$group": {"_id": {"host_address": "$host_address"}, "count": {"$sum": 1}}},
                       {"$skip": skip},
                       {"$limit": PER_PAGE}]
    query_total_url_count = [{"$match": {"app_package_name": stats}},
                             {"$group": {"_id": {"host_address": "$host_address"}, "count": {"$sum": 1}}}]
    total_app_url = list(conn2.aggregate(query_url_count))
    total_url_count = list(conn2.aggregate(query_total_url_count))

    total = len(total_url_count)
    data = []
    for tabledata in total_app_url:
        data.append({"url": tabledata['_id']['host_address'], "count": tabledata['count']})

    return {
        "total_count": total,
        "data": data
    }


def app_url_stats_malicious(package_name, page):
    skip = (page - 1) * settings.PER_PAGE
    conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_B)
    query_url_count = [{"$match": {"app_package_version_hkey": package_name, "host_response_key": 1}},
                       {"$group": {"_id": {"host_address": "$host_address"}, "count": {"$sum": 1}}}, {"$skip": skip},
                       {"$limit": PER_PAGE}]
    total_app_url = list(conn.aggregate(query_url_count))
    data = []
    for tabledata in total_app_url:
        data.append({"url": tabledata['_id']['host_address'], "count": tabledata['count']})

    return data


def os_wise_app():
    query = sql.SQL(
        'SELECT pda_version,count(*) FROM  public.user group  by pda_version')
    conn = postgres.Connection(
        host=secrets.PSQL_HOST,
        port=secrets.PSQL_PORT,
        user=secrets.PSQL_USER,
        password=secrets.PSQL_PSWD,
        db=secrets.PSQL_DB_01
    )
    # See the main query with `print(query.as_string(context=conn.connection))`
    result = conn.fetch_all(query)
    versions = [{"version": record[0], "count": record[1]} for record in result]
    count = len(versions)

    return {
        'version': versions,
        'count': count,
    }


def total_host_stats(host_address):
    conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_B)
    query_user = [{"$match": {"host_address": host_address}},
                  {"$group": {"_id": {"user_key": "$user_key"}}}]
    query_apps = [{"$match": {"host_address": host_address}},
                  {"$group": {"_id": {"app_package_version_hkey": "$app_package_version_hkey"}}}]
    host_total_user = conn.find({"host_address": host_address}).count()
    if host_total_user:
        total_users = host_total_user
    else:
        total_users = 0
    host_total_users = list(conn.aggregate(query_user))
    host_total_apps = list(conn.aggregate(query_apps))
    if host_total_users:
        total_user_count = len(host_total_users)
    else:
        total_user_count = 0
    if host_total_apps:
        total_apps_count = len(host_total_apps)
    else:
        total_apps_count = 0

    return {
        'host_total_hits': total_users,
        'host_total_users': total_user_count,
        'host_total_apps': total_apps_count,
    }


def user_installed_host_stats(host_address):
    utc_datetime_object = datetime.datetime.utcnow() - timedelta(days=30)
    comparison_timesatmp = calendar.timegm(utc_datetime_object.utctimetuple())
    dt_object = datetime.datetime.utcfromtimestamp(comparison_timesatmp)

    conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_B)

    query_last30_days_user = [{"$match": {"host_address": host_address}},
                              {"$addFields": {"ddate": {"$toDate": "$event_date"}}},
                              {"$group": {"_id": {"event_date": "$event_date"}, "count": {"$sum": 1}}}]
    last30_total_app_user = list(conn.aggregate(query_last30_days_user))
    label = []
    data = []
    for tabledata in last30_total_app_user:
        data.append(tabledata['count'])
        label.append(tabledata['_id']['event_date'])

    return {
        'label': label,
        'count': data,
    }


def user_hit_host_stats(host_address, page):
    skip = (page - 1) * settings.PER_PAGE
    conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_B)
    query_url_count = [{"$match": {"host_address": host_address}},
                       {"$group": {"_id": {"user_key": "$user_key"}, "count": {"$sum": 1}}},
                       {"$skip": skip}, {"$limit": PER_PAGE}]
    query_total_count = [{"$match": {"host_address": host_address}},
                         {"$group": {"_id": {"user_key": "$user_key"}, "count": {"$sum": 1}}}]

    total_app_url = list(conn.aggregate(query_url_count))
    total_count_url = list(conn.aggregate(query_total_count))
    total_count = (len(total_count_url))
    data = []
    for tabledata in total_app_url:
        data.append({"label": tabledata['_id']['user_key'], "count": tabledata['count']})

    return {
        'count': total_count,
        'data': data,
    }


def user_hit_app_stats(host_address, page):
    skip = (page - 1) * settings.PER_PAGE
    conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_B)
    query_url_count = [{"$match": {"host_address": host_address}},
                       {"$group": {"_id": {"app_package_name": "$app_package_name"},
                                   "count": {"$sum": 1}}},
                       {"$skip": skip}, {"$limit": PER_PAGE}]
    query_total_count = [{"$match": {"host_address": host_address}},
                         {"$group": {"_id": {"app_package_name": "$app_package_name"},
                                     "count": {"$sum": 1}}}]

    total_app_url = list(conn.aggregate(query_url_count))
    total_count_url = list(conn.aggregate(query_total_count))
    total_count = (len(total_count_url))
    data = []
    for tabledata in total_app_url:
        data.append({"label": tabledata['_id']['app_package_name'], "count": tabledata['count']})
    return {
        'count': total_count,
        'data': data,
    }


def user_app_permission_details(stats):
    conn = mongo.get_collection(db=secrets.MONGO_DB_01, col=secrets.MONGO_COL_01_C)
    query_total_permission = [{"$match": {"app_package_name": stats}},
                              {"$group": {"_id": {"permissions": "$permissions"},
                                          }}]
    app_danger_permissions = list(conn.aggregate(query_total_permission))
    total_permissions_list = []
    for per in app_danger_permissions:
        total_permissions_list.append(per['_id']['permissions'])
    updated_list = []
    for s in total_permissions_list:
        if s != None:
            updated_list += s
        else:
            pass
    print(updated_list)
    return {

        'data': updated_list,
    }
