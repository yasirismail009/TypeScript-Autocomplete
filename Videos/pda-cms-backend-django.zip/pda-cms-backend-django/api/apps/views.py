import traceback

from django.core.paginator import Paginator
from rest_framework.decorators import api_view, permission_classes, authentication_classes
from rest_framework.views import APIView

from api.apps import services

from api.apps.serializers import PackageName
from utils.responses import ok, bad_request, internal_server_error, created, not_found
from utils.util import validate_page_number


@api_view(['GET'])
@authentication_classes([])
@permission_classes([])
def app_stats(request):
    try:
        package_name = request.query_params.get('package',None)
        app_stats = services.total_app_stats(package_name)

        data = {'app_stats': app_stats}

        return ok(data=data)

    except Exception as err:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to get Package Name' + str(err))


@api_view(['GET'])
@authentication_classes([])
@permission_classes([])
def user_installed_app(request):
    try:
        package_name = request.query_params.get('package', None)
        installed_app_data = services.user_installed_apps_stats(package_name)
        data = installed_app_data

        return ok(data=data)

    except Exception as err:
        return internal_server_error(message='Failed to get Package Name' + str(err))


@api_view(['GET'])
def app_hit_url(request):
    try:

        package_name = request.query_params.get('package', None)
        page = validate_page_number(request.query_params.get('page', 1))
        app_hit_url = services.app_url_stats(package_name, page)

        data = app_hit_url

        return ok(data=data)

    except Exception as err:
        return internal_server_error(message='Failed to get Package Name' + str(err))


@api_view(['GET'])
def app_hit_url_malicious(request, package_name):
    try:
        page = validate_page_number(request.query_params.get('page', 1))
        app_hit_url_malicious = services.app_url_stats_malicious(package_name, page)
        data = app_hit_url_malicious

        return ok(data=data)

    except Exception as err:
        return internal_server_error(message='Failed to get Package Name' + str(err))


@api_view(['GET'])
def app_os_wise(request):
    try:
        app_os_wise = services.os_wise_app()
        data = app_os_wise

        return ok(data=data)

    except Exception as err:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to get Package Name' + str(err))


@api_view(['GET'])
def host_stats(request, host_address):
    try:
        host_stats = services.total_host_stats(host_address)
        data = {'host_stats': host_stats}

        return ok(data=data)

    except Exception as err:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to get Package Name' + str(err))


@api_view(['GET'])
def user_installed_host(request, host_address):
    try:
        installed_host_data = services.user_installed_host_stats(host_address)
        data = installed_host_data

        return ok(data=data)

    except Exception as err:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to get Host Address' + str(err))


@api_view(['GET'])
def user_hit_host(request, host_address):
    try:
        page = validate_page_number(request.query_params.get('page', 1))
        app_hit_url = services.user_hit_host_stats(host_address, page)
        data = app_hit_url

        return ok(data=data)

    except Exception as err:
        return internal_server_error(message='Failed to get User hit host' + str(err))


@api_view(['GET'])
def app_hit_host(request, host_address):
    try:
        page = validate_page_number(request.query_params.get('page', 1))
        app_hit_url = services.user_hit_app_stats(host_address, page)
        data = app_hit_url

        return ok(data=data)

    except Exception as err:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to get App hit host' + str(err))

@api_view(['GET'])
@authentication_classes([])
@permission_classes([])
def app_permission_details(request):
    try:
        package_name = request.query_params.get('package',None)
        app_hit_url = services.user_app_permission_details(package_name)
        data = app_hit_url

        return ok(data=data)

    except Exception as err:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to get App Permission' + str(err))



