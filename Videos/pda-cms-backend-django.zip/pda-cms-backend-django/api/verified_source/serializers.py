from datetime import date
from rest_framework.serializers import CharField, Serializer


class VerifiedSourceApiSerializer(Serializer):
    app_source = CharField(max_length=512, required=True)


class EditVerifiedSourceApiSerializer(Serializer):
    update = CharField(max_length=512, required=True)
    app_source = CharField(max_length=512, required=True)