from django.core.paginator import Paginator
from rest_framework.decorators import api_view, permission_classes, authentication_classes
from rest_framework.views import APIView

from api.apps import services

from api.verified_source.serializers import VerifiedSourceApiSerializer, EditVerifiedSourceApiSerializer
from core import secrets
from core.secrets import MONGO_DB_06, MONGO_COL_06_C
from utils import mongo
from utils.responses import ok, bad_request, internal_server_error, created, not_found
from utils.mongo import get_collection
import traceback


class VerifiedSourceApi(APIView):
    def post(self, request):
        try:
            serializer = VerifiedSourceApiSerializer(data=request.data)

            if not serializer.is_valid():
                return bad_request(data=serializer.errors, message='Failed to create Verified Source')

            verified_source_instance = serializer.validated_data
            mongo_collection = mongo.get_collection(db=secrets.MONGO_DB_06, col=secrets.MONGO_COL_06_B)
            mongo_collection.insert_one(dict(verified_source_instance))
            return created(data={'app_source': verified_source_instance.get('app_source')},
                           message='Verified Source created successfully')

        except Exception as err:
            print(err)
            return internal_server_error(message='Failed to create Verified Source')

    def get(self, request, danger_permission):
        try:
            serializer = VerifiedSourceApiSerializer(danger_permission)
            mongo_collection = mongo.get_collection(db=secrets.MONGO_DB_06, col=secrets.MONGO_COL_06_B)
            query = {"app_source": danger_permission}
            projection = {"_id": 0}
            verified_source_instance = list(mongo_collection.find_one(query, projection))

            return ok(data={'verified_source': verified_source_instance})

        except Exception as err:
            print(err)
            return internal_server_error(message='Failed to get Verified Source')

    def patch(self, request):
        try:
            print(request.data)
            serializer = EditVerifiedSourceApiSerializer(data=request.data)
            if not serializer.is_valid():
                return bad_request(data=serializer.errors, message='Failed to update Verified Source')
            updated_verified_source_instance = serializer.validated_data
            mongo_collection = mongo.get_collection(db=secrets.MONGO_DB_06, col=secrets.MONGO_COL_06_B)
            query = {"app_source": updated_verified_source_instance.get("app_source")}
            mongo_collection.update_one(query,
                                        {"$set": {"app_source": updated_verified_source_instance.get("update")}})

            return ok(data={'updated_danger_permission': updated_verified_source_instance.get("update")},
                      message='Verified Source updated successfully')

        except Exception as err:
            print(err)
            return internal_server_error(message='Failed to update verified source')

    def delete(self, request):
        try:
            serializer = VerifiedSourceApiSerializer(data=request.data)
            if not serializer.is_valid():
                return bad_request(data=serializer.errors, message='Failed to update verified source')
            delete_verified_source_instance = serializer.validated_data
            mongo_collection = mongo.get_collection(db=secrets.MONGO_DB_06, col=secrets.MONGO_COL_06_B)
            query = {"app_source": delete_verified_source_instance.get("app_source")}
            mongo_collection.delete_one(query)
            return ok(message='Verified Source deleted successfully')

        except Exception as err:
            print(err)
            return internal_server_error(message='Failed to delete verified source')


@api_view(['GET'])
def app_verified_source_listing(request):
    try:
        conn = mongo.get_collection(db=secrets.MONGO_DB_06, col=secrets.MONGO_COL_06_B)
        delete_verified_records = list(conn.find({}, {"_id": 0}))
        return ok(data={'verified_source': delete_verified_records, 'count': len(delete_verified_records)})

    except Exception:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to get verified source')
