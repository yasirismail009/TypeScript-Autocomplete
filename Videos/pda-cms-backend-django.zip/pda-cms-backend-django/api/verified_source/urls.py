from django.urls import path
from api.verified_source import views

urlpatterns = [
    path('app-verified-source-listing/', views.app_verified_source_listing),
    path('', views.VerifiedSourceApi.as_view()),

]
