from django.urls import path
from api.use_cases import views

urlpatterns = [
    path('usecase-user/', views.usecase_user),
    path('usecase-apps/', views.usecase_apps),
    path('datewise-usecase/', views.datewise_usecase),
    path('datewise-users-usecase/', views.datewise_users_usecase),
    path('top-five-apps/', views.top_five_apps),
    path('firewall-host/', views.firewall_host),
    path('sensor-usage/', views.sensor_usage),
    path('sensor-usage-stats/', views.sensor_usage_stats),
    path('sensor-usage-datewise/', views.sensor_usage_datewise),
    path('userwise-apps/', views.userwise_apps),
    path('appwise-users/', views.appwise_users),
    # path('malicious-app-othermeans-usecases/', views.malicious_app_othermeans_usecases),
    # path('sensor-duration-usecases/', views.sensor_duration_usecases),
    # path('suspicious-app-notifications/', views.suspicious_app_notifications),
    # path('suspicious-app-completed/', views.suspicious_app_completed),
    # path('unverified-app-notifications/', views.unverified_app_notifications),
    # path('unverified-app-completed/', views.unverified_app_completed),
    # path('bulk-app-notifications/', views.bulk_app_notifications),
    path('usecases-count/', views.usecases_count),
    path('usecases-count-app/', views.usecases_count_app),

]
