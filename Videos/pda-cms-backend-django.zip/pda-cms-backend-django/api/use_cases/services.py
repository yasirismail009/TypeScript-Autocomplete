import pymongo
from bson.json_util import dumps, loads
from psycopg2 import sql

from core.settings import PER_PAGE_10
from utils import mongo, util, postgres
from core import secrets, constants, settings
import datetime
from datetime import timedelta
import calendar

# Collections Access
collection_mapping = {
    'bulk_malicious': secrets.MONGO_COL_02_C,
    'calender': secrets.MONGO_COL_02_D,
    'reboot': secrets.MONGO_COL_02_D,
    'firewall': secrets.MONGO_COL_02_M,
    'malicious_app': secrets.MONGO_COL_02_E,
    'sensor_duration': secrets.MONGO_COL_02_G,
    'suspicious_notifications': secrets.MONGO_COL_02_B,
    'unverified_notifications': secrets.MONGO_COL_02_I,
    'malicious_via_other_means': secrets.MONGO_COL_02_L,
    'bulk_notifications': secrets.MONGO_COL_02_L,

}


# All Counts and Stats of Usecases
def total_usecases_count():
    malicious_count = total_bulk_process_malicious_stats()
    malicious_count["title"] = "Bulk Malicious"
    calender_count = usecase_stats(secrets.MONGO_COL_02_D, 63)
    calender_count["title"] = "Calender"
    reboot_count = usecase_stats(secrets.MONGO_COL_02_D, 65)
    reboot_count["title"] = "Reboot"
    firewall_count = usecase_stats(secrets.MONGO_COL_02_M)
    firewall_count["title"] = "Firewall"
    malicious_app_count = usecase_stats(secrets.MONGO_COL_02_E)
    malicious_app_count["title"] = "Malicious App"
    sensor_duration_count = usecase_stats(secrets.MONGO_COL_02_G)
    sensor_duration_count["title"] = "Sensor Duration"
    suspicious_notifications_count = usecase_stats_notifications(secrets.MONGO_COL_02_B)
    suspicious_notifications_count["title"] = "Suspicious Notifications"
    unverified_notifications_count = usecase_stats_notifications(secrets.MONGO_COL_02_I)
    unverified_notifications_count["title"] = "Unverified Notifications"
    malicious_app_via_other_means_use_case_count = usecase_stats(secrets.MONGO_COL_02_K)
    malicious_app_via_other_means_use_case_count["title"] = "Malicious Via Other Means"
    bulk_notifications_count = usecase_stats_notifications(secrets.MONGO_COL_02_L)
    bulk_notifications_count["title"] = "Bulk Notifications"

    data = [
        malicious_count,
        calender_count,
        reboot_count,
        firewall_count,
        malicious_app_count,
        sensor_duration_count,
        suspicious_notifications_count,
        unverified_notifications_count,
        malicious_app_via_other_means_use_case_count,
        bulk_notifications_count
    ]

    return data


# Balk Malicious stats function
def total_bulk_process_malicious_stats():
    utc_datetime_object = datetime.datetime.utcnow() - timedelta(days=30)
    utc_datetime_object_day = datetime.datetime.utcnow() - timedelta(days=1)
    comparison_timesatmp = calendar.timegm(utc_datetime_object.utctimetuple())
    comparison_timesatmp_day = calendar.timegm(utc_datetime_object_day.utctimetuple())
    # 30 days old time stamp
    dt_object = datetime.datetime.utcfromtimestamp(comparison_timesatmp)
    dt_object_day = datetime.datetime.utcfromtimestamp(comparison_timesatmp_day)
    conn = mongo.get_collection(db=secrets.MONGO_DB_02, col=secrets.MONGO_COL_02_C)
    query_total_source_last_month = [{"$match": {"job_completed_at": {"$gt": dt_object}}}]
    query_total_source_last_day = [{"$match": {"job_completed_at": {"$gt": dt_object_day}}}]
    total_source_last_month = list(conn.aggregate(query_total_source_last_month))
    total_source_last_day = list(conn.aggregate(query_total_source_last_day))
    total_source_last_month_count = (len(total_source_last_month))
    total_source_last_day_count = (len(total_source_last_day))
    total_usecase_count = conn.count();

    data = {
        'total_count': total_usecase_count,
        'last_month': total_source_last_month_count,
        'last_day': total_source_last_day_count
    }

    return data


# Function for usecase Stats
def usecase_stats(collection, rule_id=None):
    if rule_id:
        utc_datetime_object = datetime.datetime.utcnow() - timedelta(days=30)
        utc_datetime_object_day = datetime.datetime.utcnow() - timedelta(days=1)
        comparison_timesatmp = calendar.timegm(utc_datetime_object.utctimetuple())
        comparison_timesatmp_day = calendar.timegm(utc_datetime_object_day.utctimetuple())
        # 30 days old time stamp
        dt_object = datetime.datetime.utcfromtimestamp(comparison_timesatmp)
        dt_object_day = datetime.datetime.utcfromtimestamp(comparison_timesatmp_day)
        conn = mongo.get_collection(db=secrets.MONGO_DB_02, col=collection)
        query_total_source_last_month = [
            {"$match": {"use_case_triggered_at": {"$gt": dt_object}, "use_case_rule_id": rule_id}}]
        query_total_source_last_day = [
            {"$match": {"use_case_triggered_at": {"$gt": dt_object_day}, "use_case_rule_id": rule_id}}]
        total_source_last_month = list(conn.aggregate(query_total_source_last_month))
        total_source_last_day = list(conn.aggregate(query_total_source_last_day))
        total_source_last_month_count = (len(total_source_last_month))
        total_source_last_day_count = (len(total_source_last_day))
        total_usecase_count = conn.count({"use_case_rule_id": rule_id})
        data = {
            'total_count': total_usecase_count,
            'last_month': total_source_last_month_count,
            'last_day': total_source_last_day_count,
            'use_case_id': rule_id
        }

        return data
    else:
        utc_datetime_object = datetime.datetime.utcnow() - timedelta(days=30)
        utc_datetime_object_day = datetime.datetime.utcnow() - timedelta(days=1)
        comparison_timesatmp = calendar.timegm(utc_datetime_object.utctimetuple())
        comparison_timesatmp_day = calendar.timegm(utc_datetime_object_day.utctimetuple())
        # 30 days old time stamp
        dt_object = datetime.datetime.utcfromtimestamp(comparison_timesatmp)
        dt_object_day = datetime.datetime.utcfromtimestamp(comparison_timesatmp_day)
        conn = mongo.get_collection(db=secrets.MONGO_DB_02, col=collection)
        query_total_source_last_month = [{"$match": {"use_case_triggered_at": {"$gt": dt_object}}}]
        query_total_source_last_day = [{"$match": {"use_case_triggered_at": {"$gt": dt_object_day}}}]
        total_source_last_month = list(conn.aggregate(query_total_source_last_month))
        total_source_last_day = list(conn.aggregate(query_total_source_last_day))
        total_source_last_month_count = (len(total_source_last_month))
        total_source_last_day_count = (len(total_source_last_day))
        total_usecase_count = conn.count()
        cursor = conn.find({}).limit(1)
        use_case_id = loads(dumps(cursor))
        use_case = use_case_id[0]['use_case_rule_id']
        data = {
            'total_count': total_usecase_count,
            'last_month': total_source_last_month_count,
            'last_day': total_source_last_day_count,
            'use_case_id': use_case
        }

        return data


# Function for notifications usecase Stats
def usecase_stats_notifications(collection):
    utc_datetime_object = datetime.datetime.utcnow() - timedelta(days=30)
    utc_datetime_object_day = datetime.datetime.utcnow() - timedelta(days=1)
    comparison_timesatmp = calendar.timegm(utc_datetime_object.utctimetuple())
    comparison_timesatmp_day = calendar.timegm(utc_datetime_object_day.utctimetuple())
    # 30 days old time stamp
    dt_object = datetime.datetime.utcfromtimestamp(comparison_timesatmp)
    dt_object_day = datetime.datetime.utcfromtimestamp(comparison_timesatmp_day)
    conn = mongo.get_collection(db=secrets.MONGO_DB_02, col=collection)
    query_total_source_last_month = [{"$match": {"notification_sent_at": {"$gt": dt_object}}}]
    query_total_source_last_day = [{"$match": {"notification_sent_at": {"$gt": dt_object_day}}}]
    total_source_last_month = list(conn.aggregate(query_total_source_last_month))
    total_source_last_day = list(conn.aggregate(query_total_source_last_day))
    total_source_last_month_count = (len(total_source_last_month))
    total_source_last_day_count = (len(total_source_last_day))
    total_usecase_count = conn.count();
    data = {
        'total_count': total_usecase_count,
        'last_month': total_source_last_month_count,
        'last_day': total_source_last_day_count
    }

    return data


def total_usecase_user(page, usecasename):
    skip = (page - 1) * settings.PER_PAGE_10
    conn = mongo.get_collection(db=secrets.MONGO_DB_02, col=collection_mapping[usecasename])
    if usecasename == 'calender':
        query = [{"$match": {"use_case_rule_id": 63}}, {"$group": {"_id": "$user_key", "count": {"$sum": 1}}},
                 {"$sort": {"count": -1}},
                 {"$skip": skip},
                 {"$limit": PER_PAGE_10}]
        query_count = [{"$match": {"use_case_rule_id": 63}}, {"$group": {"_id": "$user_key", "count": {"$sum": 1}}}]
    elif usecasename == 'reboot':
        query = [{"$match": {"use_case_rule_id": 65}}, {"$group": {"_id": "$user_key", "count": {"$sum": 1}}},
                 {"$sort": {"count": -1}},
                 {"$skip": skip},
                 {"$limit": PER_PAGE_10}]
        query_count = [{"$match": {"use_case_rule_id": 65}}, {"$group": {"_id": "$user_key", "count": {"$sum": 1}}}]
    else:
        query = [{"$match": {}}, {"$group": {"_id": "$user_key", "count": {"$sum": 1}}}, {"$sort": {"count": -1}},
                 {"$skip": skip},
                 {"$limit": PER_PAGE_10}]
        query_count = [{"$match": {}}, {"$group": {"_id": "$user_key", "count": {"$sum": 1}}}]
    count_list = list(conn.aggregate(query_count))
    count = len(count_list)
    apps = conn.aggregate(query)

    data = {
        'list': apps,
        'count': count
    }

    return data


def total_usecase_apps(page, usecasename):
    skip = (page - 1) * settings.PER_PAGE_10
    conn = mongo.get_collection(db=secrets.MONGO_DB_02, col=collection_mapping[usecasename])
    if usecasename == 'calender':
        query = [{"$match": {"use_case_rule_id": 63}}, {"$group": {"_id": "$app_name", "count": {"$sum": 1}}},
                 {"$sort": {"count": -1}},
                 {"$skip": skip},
                 {"$limit": PER_PAGE_10}]
        query_count = [{"$match": {"use_case_rule_id": 63}}, {"$group": {"_id": "$app_name", "count": {"$sum": 1}}}]
    elif usecasename == 'reboot':
        query = [{"$match": {"use_case_rule_id": 65}}, {"$group": {"_id": "$app_name", "count": {"$sum": 1}}},
                 {"$sort": {"count": -1}},
                 {"$skip": skip},
                 {"$limit": PER_PAGE_10}]
        query_count = [{"$match": {"use_case_rule_id": 65}}, {"$group": {"_id": "$app_name", "count": {"$sum": 1}}}]
    else:
        query = [{"$match": {}}, {"$group": {"_id": "$app_name", "count": {"$sum": 1}}}, {"$sort": {"count": -1}},
                 {"$skip": skip},
                 {"$limit": PER_PAGE_10}]
        query_count = [{"$match": {}}, {"$group": {"_id": "$app_name", "count": {"$sum": 1}}}]
    count_list = list(conn.aggregate(query_count))
    count = len(count_list)
    apps = conn.aggregate(query)
    if apps:
        app = apps
    else:
        app = 0
    data = {
        'list': app,
        'count': count
    }

    return data


def total_datewise_usecase(usecasename):
    conn = mongo.get_collection(db=secrets.MONGO_DB_02, col=collection_mapping[usecasename])
    if usecasename == 'suspicious_notifications' or usecasename == 'unverified_notifications' or usecasename == 'bulk_notifications' or usecasename == 'bulk_malicious':
        query_datewise_user = [{"$match": {}},
                               {"$group": {"_id": {"notification_sent_at": "$notification_sent_at"},
                                           "count": {"$sum": 1}}}, {'$limit': 30}, ]
        total_datewise_user = list(conn.aggregate(query_datewise_user))
        label = []
        data = []

        for tabledata in total_datewise_user:
            data.append(tabledata['count'])
            label.append(tabledata['_id']['notification_sent_at'])
    elif usecasename == 'calender':
        query_datewise_user = [{"$match": {"use_case_rule_id": 63}},
                               {"$group": {"_id": {"use_case_triggered_at": "$use_case_triggered_at"},
                                           "count": {"$sum": 1}}}, {'$limit': 30}, ]
        total_datewise_user = list(conn.aggregate(query_datewise_user))
        label = []
        data = []

        for tabledata in total_datewise_user:
            data.append(tabledata['count'])
            label.append(tabledata['_id']['use_case_triggered_at'])
    elif usecasename == 'reboot':
        query_datewise_user = [{"$match": {"use_case_rule_id": 65}},
                               {"$group": {"_id": {"use_case_triggered_at": "$use_case_triggered_at"},
                                           "count": {"$sum": 1}}}, {'$limit': 30}, ]
        total_datewise_user = list(conn.aggregate(query_datewise_user))
        label = []
        data = []

        for tabledata in total_datewise_user:
            data.append(tabledata['count'])
            label.append(tabledata['_id']['use_case_triggered_at'])
    else:
        query_datewise_user = [{"$match": {}},
                               {"$group": {"_id": {"use_case_triggered_at": "$use_case_triggered_at"},
                                           "count": {"$sum": 1}}}, {'$limit': 30}, ]
        total_datewise_user = list(conn.aggregate(query_datewise_user))
        label = []
        data = []

        for tabledata in total_datewise_user:
            data.append(tabledata['count'])
            label.append(tabledata['_id']['use_case_triggered_at'])

    return {
        'label': label,
        'count': data,
    }


def total_datewise_users_usecase(usecasename):
    conn = mongo.get_collection(db=secrets.MONGO_DB_02, col=collection_mapping[usecasename])
    if usecasename == 'suspicious_notifications' or usecasename == 'unverified_notifications' or usecasename == 'bulk_notifications' or usecasename == 'bulk_malicious':
        query_datewise_user = [{"$match": {}},
                               {"$addFields": {"ddate": {"$toDate": "$notification_sent_at"}}},
                               {"$group": {"_id": {"notification_sent_at": "$notification_sent_at"},
                                           "users": {"$addToSet": "$user_key"},
                                           "count": {"$sum": 1}}},
                               {
                                   "$project": {"date": "$_id.notification_sent_at", "_id": 0,
                                                "user_count": {"$size": "$users"}}}, {'$limit': 30}, ]
    elif usecasename == 'calender':
        query_datewise_user = [{"$match": {"use_case_rule_id": 63}},
                               {"$addFields": {"ddate": {"$toDate": "$use_case_triggered_at"}}},
                               {"$group": {"_id": {"use_case_triggered_at": "$use_case_triggered_at"},
                                           "users": {"$addToSet": "$user_key"},
                                           "count": {"$sum": 1}}},
                               {
                                   "$project": {"date": "$_id.use_case_triggered_at", "_id": 0,
                                                "user_count": {"$size": "$users"}}}, {'$limit': 30}, ]
    elif usecasename == 'reboot':
        query_datewise_user = [{"$match": {"use_case_rule_id": 65}},
                               {"$addFields": {"ddate": {"$toDate": "$use_case_triggered_at"}}},
                               {"$group": {
                                   "_id": {"use_case_triggered_at": "$use_case_triggered_at"},
                                   "users": {"$addToSet": "$user_key"},
                                   "count": {"$sum": 1}}},
                               {
                                   "$project": {"date": "$_id.use_case_triggered_at", "_id": 0,
                                                "user_count": {"$size": "$users"}}},
                               {'$limit': 30}, ]
    else:
        query_datewise_user = [{"$match": {}},
                               {"$addFields": {"ddate": {"$toDate": "$use_case_triggered_at"}}},
                               {"$group": {"_id": {"use_case_triggered_at": "$use_case_triggered_at"},
                                           "users": {"$addToSet": "$user_key"},
                                           "count": {"$sum": 1}}},
                               {
                                   "$project": {"date": "$_id.use_case_triggered_at", "_id": 0,
                                                "user_count": {"$size": "$users"}}}, {'$limit': 30}, ]
    total_datewise_user = list(conn.aggregate(query_datewise_user))
    label = []
    data = []

    for tabledata in total_datewise_user:
        data.append(tabledata['user_count'])
        label.append(tabledata['date'])

    # last_month_count = len(app_id_last_month)
    # last_day_count = len(app_id_last_day)

    return {
        'label': label,
        'count': data,
    }


def total_top_five_apps(usecasename):
    conn = mongo.get_collection(db=secrets.MONGO_DB_02, col=collection_mapping[usecasename])

    query = [{"$group": {"_id": "$app_name", "count": {"$sum": 1}}},
             {"$match": {"count": {"$gt": 1}}}, {'$limit': 5}]
    apps = list(conn.aggregate(query))

    label = []
    count = []

    if apps:
        for data in apps:
            label.append(data['_id'])
            count.append(data['count'])
    else:
        apps_data = 0
    data = {
        'label': label,
        'count': count
    }
    return data


def total_firewall_hots(page):
    skip = (page - 1) * settings.PER_PAGE_10
    conn = mongo.get_collection(db=secrets.MONGO_DB_02, col=secrets.MONGO_COL_02_M)
    query = [{"$match": {}}, {"$group": {"_id": "$host_address", "count": {"$sum": 1}}},
             {"$sort": {"count": -1}},
             {"$skip": skip},
             {"$limit": PER_PAGE_10}]
    query_count = [{"$match": {}}, {"$group": {"_id": "$host_address", "count": {"$sum": 1}}}]

    count_list = list(conn.aggregate(query_count))
    count = len(count_list)
    apps = conn.aggregate(query)
    if apps:
        app = apps
    else:
        app = 0
    data = {
        'list': app,
        'count': count
    }

    return data


def total_sensor_usage():
    conn = mongo.get_collection(db=secrets.MONGO_DB_02, col=secrets.MONGO_COL_02_G)
    query = [{"$match": {}}, {"$group": {"_id": "$sensor_key", "count": {"$sum": 1}}},
             {"$sort": {"count": -1}}]
    query_count = [{"$match": {}}, {"$group": {"_id": "$sensor_key", "count": {"$sum": 1}}}]

    count_list = list(conn.aggregate(query_count))
    apps = conn.aggregate(query)
    label = []
    count = []
    for sensor in apps:
        if sensor['_id'] == 2:
            label.append("Mic")
            count.append(sensor['count'])
        else:
            label.append("Camera")
            count.append(sensor['count'])

    data = {
        'label': label,
        'count': count,
    }

    return data


def total_sensor_usage_stats():
    conn = mongo.get_collection(db=secrets.MONGO_DB_02, col=secrets.MONGO_COL_02_G)
    query = [{"$group": {"_id": {"sensor_key": "$sensor_key"}
        , "max_duration": {"$max": "$duration"}, "avg_duration": {"$avg": "$duration"},
                         "min_duration": {"$min": "$duration"}, }}]
    apps = list(conn.aggregate(query))
    data_records = []
    for app in apps:
        if app['_id']['sensor_key'] == 2:
            sensor = 'Mic'
        else:
            sensor = 'Camera'
        max_duration = app['max_duration'] / 1000.0
        min_duration = app['min_duration'] / 1000.0
        avg_duration = app['avg_duration'] / 1000.0
        data = {
            'sensor': sensor,
            'max_duration': max_duration,
            'min_duration': min_duration,
            'avg_duration': avg_duration,
        }
        data_records.append(data)

    return data_records


def total_sensor_usage_datewise():
    conn = mongo.get_collection(db=secrets.MONGO_DB_02, col=secrets.MONGO_COL_02_G)
    query = [
        {"$group": {"_id": {"use_case_triggered_at": "$use_case_triggered_at"}, "sensor": {"$addToSet": "$sensor_key"}
            , "max_duration": {"$max": "$duration"}, "avg_duration": {"$avg": "$duration"},
                    "min_duration": {"$min": "$duration"}, }}]
    apps = list(conn.aggregate(query))
    max_duration = []
    min_duration = []
    avg_duration = []
    label = []
    sensor = []
    for app in apps:
        label.append(app['_id']['use_case_triggered_at'])
        if app['sensor'][0] == 2:
            sensor.append('Mic')
        else:
            sensor.append('Camera')
        max_duration.append((app['max_duration'] / 1000.0))
        min_duration.append((app['min_duration'] / 1000.0))
        avg_duration.append((app['avg_duration'] / 1000.0))
    data = {
        'label': label,
        'sensor': sensor,
        'max': max_duration,
        'min': min_duration,
        'avg': avg_duration,
    }

    return data


def total_userwise_apps(usecase_name, key):
    userkey= int(key)
    conn = mongo.get_collection(db=secrets.MONGO_DB_02, col=collection_mapping[usecase_name])
    query = [{"$match": {"user_key": userkey}}, {"$group": {"_id": '$app_name', "count": {"$sum": 1}}}]
    apps = list(conn.aggregate(query))
    data = apps

    return data


def total_appwise_users(usecase_name, app):
    conn = mongo.get_collection(db=secrets.MONGO_DB_02, col=collection_mapping[usecase_name])
    query = [{"$match": {"app_name": app}}, {"$group": {"_id": '$user_key', "count": {"$sum": 1}}}]
    apps = list(conn.aggregate(query))
    data = apps

    return data
