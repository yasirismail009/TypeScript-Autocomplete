import traceback

from django.core.paginator import Paginator
from rest_framework.decorators import api_view, permission_classes, authentication_classes
from rest_framework.views import APIView

from api.use_cases import services

from utils.responses import ok, bad_request, internal_server_error, created, not_found
from utils.util import validate_page_number


@api_view(['GET'])
def usecases_count(request):
    try:
        app_stats = services.total_usecases_count()
        data = app_stats

        return ok(data=data)

    except Exception as err:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to get malicious count by date' + str(err))

#user
@api_view(['GET'])
def usecase_user(request):
    try:
        usecase_name = request.query_params.get('usecase', None)
        page = validate_page_number(request.query_params.get('page', 1))
        app_stats = services.total_usecase_user(page, usecase_name)
        data = app_stats

        return ok(data=data)

    except Exception as err:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to get malicious count by date' + str(err)) @ api_view(['GET'])

#apps
@api_view(['GET'])
def usecase_apps(request):
    try:
        usecase_name = request.query_params.get('usecase', None)
        page = validate_page_number(request.query_params.get('page', 1))
        app_stats = services.total_usecase_apps(page, usecase_name)
        data = app_stats

        return ok(data=data)

    except Exception as err:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to get malicious count by date' + str(err)) @ api_view(['GET'])


#datewise
@api_view(['GET'])
def datewise_usecase(request):
    try:
        usecase_name = request.query_params.get('usecase', None)
        app_stats = services.total_datewise_usecase(usecase_name)
        data = app_stats

        return ok(data=data)

    except Exception as err:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to get malicious count by date' + str(err)) @ api_view(['GET'])

#deatewise users
@api_view(['GET'])
def datewise_users_usecase(request):
    try:
        usecase_name = request.query_params.get('usecase', None)
        app_stats = services.total_datewise_users_usecase(usecase_name)
        data = app_stats

        return ok(data=data)

    except Exception as err:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to get malicious count by date' + str(err))

#top apps
@api_view(['GET'])
def top_five_apps(request):
    try:
        usecase_name = request.query_params.get('usecase', None)
        app_stats = services.total_top_five_apps(usecase_name)
        data = app_stats

        return ok(data=data)

    except Exception as err:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to get malicious count by date' + str(err))

#firewall Host
@api_view(['GET'])
def firewall_host(request):
    try:
        page = validate_page_number(request.query_params.get('page', 1))
        app_stats = services.total_firewall_hots(page)
        data = app_stats

        return ok(data=data)

    except Exception as err:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to get malicious count by date' + str(err))


@api_view(['GET'])
def sensor_usage(request):
    try:
        app_stats = services.total_sensor_usage()
        data = app_stats

        return ok(data=data)

    except Exception as err:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to get malicious count by date' + str(err))



@api_view(['GET'])
def sensor_usage_stats(request):
    try:
        app_stats = services.total_sensor_usage_stats()
        data = app_stats

        return ok(data=data)

    except Exception as err:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to get malicious count by date' + str(err))




@api_view(['GET'])
def sensor_usage_datewise(request):
    try:
        app_stats = services.total_sensor_usage_datewise()
        data = app_stats

        return ok(data=data)

    except Exception as err:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to get malicious count by date' + str(err))


@api_view(['GET'])
def usecases_count_app(request):
    try:
        package_name = validate_page_number(request.query_params.get('package_name', None))
        app_stats = services.total_usecases_count_app(package_name)
        data = app_stats

        return ok(data=data)

    except Exception as err:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to get malicious count by date' + str(err))


@api_view(['GET'])
def userwise_apps(request):
    try:
        usecase_name = request.query_params.get('usecase', None)
        user_key = request.query_params.get('user_key', None)
        app_stats = services.total_userwise_apps(usecase_name,user_key)
        data = app_stats

        return ok(data=data)

    except Exception as err:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to get malicious count by date' + str(err))


@api_view(['GET'])
def appwise_users(request):
    try:
        usecase_name = request.query_params.get('usecase', None)
        app_name = request.query_params.get('app_name', None)
        app_stats = services.total_appwise_users(usecase_name,app_name)
        data = app_stats

        return ok(data=data)

    except Exception as err:
        print(traceback.format_exc())
        return internal_server_error(message='Failed to get malicious count by date' + str(err))
